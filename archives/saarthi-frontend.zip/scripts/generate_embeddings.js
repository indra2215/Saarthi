const fs = require('fs');
const path = require('path');

const API_KEY = process.env.GEMINI_API_KEY || 'AQ.Ab8RN6KM27--cpceBInW3dWkeehL4XLLHjxys0SIyTnQTVWUfg';
const enrichedPath = path.join(__dirname, '..', 'data', 'faculty.enriched.json');
const outputPath = path.join(__dirname, '..', 'data', 'faculty.vectors.json');

async function embedText(text, retries = 3) {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-embedding-001:embedContent?key=${API_KEY}`;
  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          content: { parts: [{ text }] }
        })
      });
      if (res.status === 429) {
        console.log(`Rate limit hit, waiting 3s before attempt ${attempt + 1}...`);
        await new Promise(r => setTimeout(r, 3000 * attempt));
        continue;
      }
      if (!res.ok) {
        const errText = await res.text();
        throw new Error(`HTTP ${res.status}: ${errText}`);
      }
      const data = await res.json();
      if (!data.embedding || !data.embedding.values) {
        throw new Error('No embedding returned');
      }
      return data.embedding.values;
    } catch (err) {
      if (attempt === retries) throw err;
      await new Promise(r => setTimeout(r, 1500 * attempt));
    }
  }
}

async function main() {
  console.log('Loading faculty data from:', enrichedPath);
  const faculty = JSON.parse(fs.readFileSync(enrichedPath, 'utf8'));
  console.log(`Found ${faculty.length} faculty records. Starting embedding generation...`);

  // Check if we have partial progress to resume
  let existingVectors = {};
  if (fs.existsSync(outputPath)) {
    try {
      const existing = JSON.parse(fs.readFileSync(outputPath, 'utf8'));
      existing.forEach(item => {
        if (item.chunk_id && item.embedding && item.embedding.length > 0) {
          existingVectors[item.chunk_id] = item.embedding;
        }
      });
      console.log(`Resuming with ${Object.keys(existingVectors).length} existing embeddings.`);
    } catch (e) {
      console.log('Starting fresh.');
    }
  }

  const results = [];
  for (let i = 0; i < faculty.length; i++) {
    const f = faculty[i];
    const chunk_id = f.chunk_id;

    if (existingVectors[chunk_id]) {
      results.push({ chunk_id, embedding: existingVectors[chunk_id] });
      continue;
    }

    const textToEmbed = f.rag_metadata?.embedding_text || `${f.faculty_name} ${f.department} ${f.primary_domain} ${(f.research_areas || []).join(' ')}`;
    process.stdout.write(`[${i + 1}/${faculty.length}] Embedding ${chunk_id} (${f.faculty_name})... `);

    try {
      const vec = await embedText(textToEmbed);
      results.push({ chunk_id, embedding: vec });
      console.log(`✓ (${vec.length} dims)`);
    } catch (err) {
      console.error(`✗ Error: ${err.message}`);
    }

    // Save checkpoint every 10 records
    if ((i + 1) % 10 === 0 || i === faculty.length - 1) {
      fs.writeFileSync(outputPath, JSON.stringify(results, null, 2));
    }

    // Short delay to respect API rate limits
    await new Promise(r => setTimeout(r, 200));
  }

  fs.writeFileSync(outputPath, JSON.stringify(results, null, 2));
  console.log(`\n🎉 Successfully embedded ${results.length} faculty chunks into ${outputPath}`);
}

main().catch(err => {
  console.error('Fatal error:', err);
  process.exit(1);
});
