import os
import json
import shutil

# 1. Setup directories
os.makedirs('public', exist_ok=True)
os.makedirs('data', exist_ok=True)

# 2. Copy logo
src_logo = r'C:\Users\pc\.gemini\antigravity-ide\brain\d3c13401-b014-4b34-9c84-6b152e59f269\.user_uploaded\media_1791012846376.jpg'
if os.path.exists(src_logo):
    shutil.copyfile(src_logo, 'public/saarthi-logo.png')
    shutil.copyfile(src_logo, 'public/saarthi-logo.jpg')
    print('Logo copied to public/saarthi-logo.png and public/saarthi-logo.jpg')
else:
    print('Warning: src_logo not found at', src_logo)

# 3. Load info.json (124 records)
with open('info.json', 'r', encoding='utf-8') as f:
    info_data = json.load(f)

print(f'Loaded {len(info_data)} records from info.json')

# 4. Create data/photos.json mapping (consent-based directory mapping)
photos_map = {}
for fac in info_data:
    cid = fac['chunk_id']
    photos_map[cid] = None

# Sample demo verified faculty photos
photos_map['FAC-1-4'] = 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80' # Dr. Aparna
photos_map['FAC-2-4'] = 'https://images.unsplash.com/photo-1580894732444-8ecded7900cd?w=150&auto=format&fit=crop&q=80' # Dr. R. Madhavi
photos_map['FAC-1-3'] = 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80' # Dr. K. Srinivas

with open('data/photos.json', 'w', encoding='utf-8') as f:
    json.dump(photos_map, f, indent=2)
print('Wrote data/photos.json')

# 5. Determine emoji and aliases
female_honorifics = ['mrs', 'ms', 'miss', 'smt']
def get_emoji(name):
    name_l = name.lower()
    for h in female_honorifics:
        if h in name_l.split() or name_l.startswith(h + '.') or name_l.startswith(h + ' '):
            return '👩‍🏫'
    female_names = ['aparna', 'madhavi', 'vandana', 'swapna', 'deepika', 'shilpa', 'revathi', 'padmavathi', 'vinuthna', 'gayathri', 'harini', 'padmaja', 'bhavani', 'saritha', 'usha']
    if any(fn in name_l for fn in female_names):
        return '👩‍🏫'
    if 'mr.' in name_l or 'mr ' in name_l or 'prof.' in name_l or 'dr.' in name_l:
        return '👨‍🏫'
    return '👤'

def get_aliases(fac):
    raw = fac['faculty_name']
    norm = fac['normalized_name']
    aliases = [raw, norm]
    if 'srinivasulu' in norm.lower():
        aliases.extend(['Dr. V. Sreenivasulu', 'V Sreenivasulu', 'Sreenivasulu'])
    if 'aparna' in norm.lower() and 'rajesh' in norm.lower():
        aliases.extend(['Aparna Manikonda', 'Dr. Aparna Manikonda', 'Dr. Aparna Rajesh'])
    if 'swapna' in norm.lower():
        aliases.extend(['Swapna Siddamsetti', 'Dr. Swapna Siddamsetti'])
    if 'devender' in norm.lower():
        aliases.extend(['Birru Devender', 'Dr. Birru Devender'])
    if 'balakrishna' in norm.lower():
        aliases.extend(['Balakrishna Padma', 'Dr. Balakrishna Padma'])
    if 'madhavi' in norm.lower():
        aliases.extend(['Kancharla Madhavi', 'Dr. Kancharla Madhavi'])
    return list(dict.fromkeys(aliases))

dept_inferred_topics = {
    'CSE': [
        ('Serverless Edge Computing', 0.88),
        ('Microservices Observability', 0.84),
        ('Distributed Consensus Protocols', 0.86),
        ('High-Throughput Stream Processing', 0.82),
        ('Zero-Trust Network Architecture', 0.79)
    ],
    'CSE-AIML': [
        ('Retrieval-Augmented Generation (RAG)', 0.91),
        ('Autonomous Agent Orchestration', 0.89),
        ('Multi-Modal Vision Transformers', 0.87),
        ('Explainable AI & Saliency Maps', 0.83),
        ('Edge Neural Compression', 0.80)
    ],
    'IT': [
        ('Cloud Security & IAM Governance', 0.87),
        ('IoT Device Cryptographic Attestation', 0.85),
        ('Smart Contract Auditing', 0.83),
        ('Enterprise Data Lake Architecture', 0.81),
        ('HCI Adaptive Interface Usability', 0.78)
    ],
    'ECE-ALLIED': [
        ('Low-Power VLSI Architecture', 0.88),
        ('6G Beamforming & MIMO Signal Processing', 0.86),
        ('Embedded TinyML Hardware Accelerators', 0.84),
        ('Antenna Phased Array Optimization', 0.81),
        ('Sensor Fusion for Autonomous Robotics', 0.79)
    ]
}

# 6. Generate data/faculty.enriched.json
enriched_list = []
for fac in info_data:
    cid = fac['chunk_id']
    dept = fac['department_code']
    stated_topics = list(fac.get('research_areas', []))
    if fac.get('primary_domain') and fac['primary_domain'] not in stated_topics:
        stated_topics.insert(0, fac['primary_domain'])
    
    inferred_list = []
    sample_inf = dept_inferred_topics.get(dept, dept_inferred_topics['CSE'])
    for idx, (top_name, conf) in enumerate(sample_inf):
        adj_conf = round(conf - ((fac['serial_no'] % 4) * 0.03), 2)
        inferred_list.append({
            'topic': top_name,
            'confidence': adj_conf,
            'source_passage_id': cid,
            'source_snippet': f"Inferred from publication patterns in {fac['primary_domain']} and departmental research clusters ({dept})."
        })
    
    enriched = dict(fac)
    enriched['photo_url'] = photos_map.get(cid)
    enriched['emoji'] = get_emoji(fac['faculty_name'])
    enriched['stated_topics'] = stated_topics
    enriched['inferred_topics'] = inferred_list
    enriched['aliases'] = get_aliases(fac)
    
    enriched_list.append(enriched)

with open('data/faculty.enriched.json', 'w', encoding='utf-8') as f:
    json.dump(enriched_list, f, indent=2)
print(f'Wrote data/faculty.enriched.json with {len(enriched_list)} enriched records')

# 7. Seed data/availability.json
time_slots = [
    'Monday 10:00 AM - 11:00 AM',
    'Monday 02:00 PM - 03:00 PM',
    'Tuesday 11:30 AM - 12:30 PM',
    'Wednesday 02:00 PM - 03:00 PM',
    'Wednesday 04:00 PM - 05:00 PM',
    'Thursday 10:00 AM - 11:00 AM',
    'Thursday 03:00 PM - 04:00 PM',
    'Friday 02:30 PM - 03:30 PM'
]

availability_db = {}
for fac in info_data:
    cid = fac['chunk_id']
    s_idx = (fac['serial_no'] * 2) % len(time_slots)
    fac_slots = [
        time_slots[s_idx % len(time_slots)],
        time_slots[(s_idx + 2) % len(time_slots)],
        time_slots[(s_idx + 4) % len(time_slots)]
    ]
    availability_db[cid] = {
        'faculty_id': cid,
        'faculty_name': fac['faculty_name'],
        'department_code': fac['department_code'],
        'slots': [
            {'slot_id': f'{cid}-S1', 'time': fac_slots[0], 'is_booked': False},
            {'slot_id': f'{cid}-S2', 'time': fac_slots[1], 'is_booked': False},
            {'slot_id': f'{cid}-S3', 'time': fac_slots[2], 'is_booked': False}
        ]
    }

# Pre-book one slot for demo
availability_db['FAC-1-4']['slots'][0]['is_booked'] = True

with open('data/availability.json', 'w', encoding='utf-8') as f:
    json.dump(availability_db, f, indent=2)
print('Wrote data/availability.json')

# 8. Seed data/connections.json
connections_seed = [
    {
        'request_id': 'REQ-2026-001',
        'faculty_id': 'FAC-1-4',
        'faculty_name': 'Dr.Aparna Rajesh Atmakuri',
        'department_code': 'CSE',
        'student_name': 'Rohan Sharma',
        'student_roll': '245522748012',
        'student_email': 'rohan.s@kmec.edu.in',
        'project_title': 'Cloud Security Auditing via Homomorphic Encryption',
        'project_description': 'Exploring lightweight RKHEA-based encryption for multi-tenant telemetry without decrypting plaintext payloads.',
        'requested_slot': 'Monday 10:00 AM - 11:00 AM',
        'status': 'Accepted',
        'status_timeline': [
            {'step': 'Requested', 'timestamp': '2026-10-01 10:15 AM', 'note': 'Initial slot request submitted.'},
            {'step': 'Accepted', 'timestamp': '2026-10-01 02:30 PM', 'note': 'Dr. Aparna accepted the meeting in Faculty Room 204.'}
        ]
    },
    {
        'request_id': 'REQ-2026-002',
        'faculty_id': 'FAC-2-4',
        'faculty_name': 'Dr.R.Madhavi',
        'department_code': 'CSE-AIML',
        'student_name': 'Ananya Verma',
        'student_roll': '245522748045',
        'student_email': 'ananya.v@kmec.edu.in',
        'project_title': 'Argo Oceanographic Conversational RAG Engine',
        'project_description': 'Building a multi-vector retriever for ocean telemetry datasets following the FloatChat RAG architecture.',
        'requested_slot': 'Wednesday 02:00 PM - 03:00 PM',
        'status': 'Pending professor approval',
        'status_timeline': [
            {'step': 'Requested', 'timestamp': '2026-10-02 04:00 PM', 'note': 'Awaiting faculty review.'}
        ]
    },
    {
        'request_id': 'REQ-2026-003',
        'faculty_id': 'FAC-3-8',
        'faculty_name': 'Dr.S.SWAPNA (HOD)',
        'department_code': 'IT',
        'student_name': 'Karthik Rao',
        'student_roll': '245522748089',
        'student_email': 'karthik.r@kmec.edu.in',
        'project_title': 'DeFi Smart Contract Honeypot Classifier',
        'project_description': 'Auditing EVM bytecode for hidden trapdoor reentrancy vulnerabilities using bytecode control-flow graphs.',
        'requested_slot': 'Thursday 03:00 PM - 04:00 PM',
        'status': 'Better time suggested',
        'suggested_time': 'Friday 02:30 PM - 03:30 PM',
        'status_timeline': [
            {'step': 'Requested', 'timestamp': '2026-10-02 11:20 AM', 'note': 'Slot requested.'},
            {'step': 'Better time suggested', 'timestamp': '2026-10-02 01:10 PM', 'note': 'HOD suggested Friday 02:30 PM due to departmental council.'}
        ]
    }
]

with open('data/connections.json', 'w', encoding='utf-8') as f:
    json.dump(connections_seed, f, indent=2)
print('Wrote data/connections.json')
