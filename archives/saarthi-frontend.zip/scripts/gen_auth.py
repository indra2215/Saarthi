import json

with open('data/faculty.enriched.json', 'r', encoding='utf-8') as f:
    faculty = json.load(f)

auth = {}
for fac in faculty:
    cid = fac['chunk_id']
    serial = fac['serial_no']
    dept = fac['department_code'].replace('&','').replace('-','').lower()
    password = f'kmec{dept}{serial:02d}'
    username = cid.lower().replace('-', '_')
    auth[cid] = {
        'faculty_id': cid,
        'faculty_name': fac['faculty_name'],
        'department_code': fac['department_code'],
        'username': username,
        'password': password,
    }

with open('data/faculty_auth.json', 'w', encoding='utf-8') as fout:
    json.dump(auth, fout, indent=2)

print(f'Generated auth for {len(auth)} faculty')
samples = list(auth.items())[:5]
for cid, v in samples:
    print(cid, v['username'], v['password'])
