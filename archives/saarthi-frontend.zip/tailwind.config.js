/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        cream: {
          50: '#FBF4E4',
          100: '#F7ECD6', // primary page bg (matches logo bg)
          200: '#EBDDBF',
          300: '#DFCBA7',
        },
        brown: {
          900: '#3E1F0D', // primary text (matches logo text)
          700: '#5A2D12', // primary brand
          600: '#733D19',
          500: '#8A5A2B',
          400: '#A47242',
          100: '#F0E2D2',
        },
        gold: {
          300: '#DDB373',
          400: '#C9964F', // accent (matches logo gradient head)
          500: '#B07E36',
          100: '#F6EBD8',
        }
      },
      fontFamily: {
        heading: ['Outfit', 'Poppins', 'sans-serif'],
        body: ['Inter', 'sans-serif'],
      },
      boxShadow: {
        'soft': '0 4px 20px -2px rgba(62, 31, 13, 0.08)',
        'elevated': '0 10px 30px -5px rgba(62, 31, 13, 0.12)',
        'glow-gold': '0 0 25px rgba(201, 150, 79, 0.45)',
      }
    },
  },
  plugins: [],
};
