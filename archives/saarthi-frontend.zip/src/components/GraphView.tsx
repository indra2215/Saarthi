'use client';

import { useRef, useMemo, useState, useEffect } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { OrbitControls, Text, Billboard } from '@react-three/drei';
import * as THREE from 'three';
import { Faculty } from '@/types';

// ─── Constants ────────────────────────────────────────────────────────────────
const DEPT_COLORS: Record<string, string> = {
  'CSE':        '#3b82f6',
  'CSE-AIML':   '#8b5cf6',
  'IT':         '#10b981',
  'ECE-ALLIED': '#f59e0b',
  'H&S':        '#ef4444',
};

function hexToThree(hex: string): THREE.Color {
  return new THREE.Color(hex);
}

// ─── Types ────────────────────────────────────────────────────────────────────
interface NodeData {
  id: string;
  label: string;
  type: 'faculty' | 'topic' | 'department';
  dept?: string;
  faculty?: Faculty;
  pos: THREE.Vector3;          // current position (mutable by sim)
  vel: THREE.Vector3;
  targetPos: THREE.Vector3;    // where it should settle
}

interface LinkData {
  a: NodeData;
  b: NodeData;
  strength: number;
}

// ─── Build graph data from faculty array ──────────────────────────────────────
function buildGraph(faculty: Faculty[], highlightIds: Set<string>): { nodes: NodeData[]; links: LinkData[] } {
  const nodes: NodeData[] = [];
  const nodeMap: Record<string, NodeData> = {};

  const rnd = (scale = 1) => (Math.random() - 0.5) * 2 * scale;
  const spread = 12;

  // Dept nodes — place at fixed ring positions
  const depts = Array.from(new Set(faculty.map(f => f.department_code)));
  depts.forEach((d, i) => {
    const angle = (i / depts.length) * Math.PI * 2;
    const pos = new THREE.Vector3(
      Math.cos(angle) * 6,
      Math.sin(angle) * 2,
      Math.sin(angle) * 6,
    );
    const node: NodeData = {
      id: `dept_${d}`, label: d, type: 'department', dept: d,
      pos: pos.clone(), vel: new THREE.Vector3(), targetPos: pos.clone(),
    };
    nodes.push(node);
    nodeMap[`dept_${d}`] = node;
  });

  // Faculty nodes
  faculty.forEach(f => {
    const pos = new THREE.Vector3(rnd(spread), rnd(spread * 0.6), rnd(spread));
    const node: NodeData = {
      id: f.chunk_id, label: f.normalized_name, type: 'faculty', dept: f.department_code,
      faculty: f, pos: pos.clone(), vel: new THREE.Vector3(), targetPos: pos.clone(),
    };
    nodes.push(node);
    nodeMap[f.chunk_id] = node;
  });

  // Topic nodes (top 25 most common to keep it clean)
  const topicCount: Record<string, number> = {};
  faculty.forEach(f => f.stated_topics.slice(0, 2).forEach(t => { topicCount[t] = (topicCount[t] || 0) + 1; }));
  const topTopics = Object.entries(topicCount).sort((a, b) => b[1] - a[1]).slice(0, 25).map(e => e[0]);

  topTopics.forEach(topic => {
    const tid = `topic_${topic.replace(/[^a-zA-Z0-9]/g, '_')}`;
    if (!nodeMap[tid]) {
      const pos = new THREE.Vector3(rnd(spread * 0.8), rnd(spread * 0.4), rnd(spread * 0.8));
      const node: NodeData = {
        id: tid, label: topic, type: 'topic',
        pos: pos.clone(), vel: new THREE.Vector3(), targetPos: pos.clone(),
      };
      nodes.push(node);
      nodeMap[tid] = node;
    }
  });

  // Links
  const links: LinkData[] = [];
  faculty.forEach(f => {
    const fn = nodeMap[f.chunk_id];
    const dn = nodeMap[`dept_${f.department_code}`];
    if (fn && dn) links.push({ a: fn, b: dn, strength: 1.5 });

    f.stated_topics.slice(0, 2).forEach(topic => {
      const tid = `topic_${topic.replace(/[^a-zA-Z0-9]/g, '_')}`;
      const tn = nodeMap[tid];
      if (fn && tn) links.push({ a: fn, b: tn, strength: 0.8 });
    });
  });

  return { nodes, links };
}

// ─── Individual sphere node ────────────────────────────────────────────────────
function GraphNode({
  node,
  highlighted,
  faded,
  onClick,
}: {
  node: NodeData;
  highlighted: boolean;
  faded: boolean;
  onClick: () => void;
}) {
  const meshRef = useRef<THREE.Mesh>(null!);
  const glowRef = useRef<THREE.Mesh>(null!);
  const t = useRef(Math.random() * Math.PI * 2);

  const baseColor = node.dept ? hexToThree(DEPT_COLORS[node.dept] || '#C9964F')
    : node.type === 'topic' ? new THREE.Color('#C9964F')
    : new THREE.Color('#8A5A2B');

  const radius = node.type === 'department' ? 0.7
    : node.type === 'faculty' ? 0.38
    : 0.22;

  useFrame((_, delta) => {
    t.current += delta * (node.type === 'faculty' ? 0.4 : 0.2);

    // Gentle idle float
    if (!highlighted && node.type !== 'department') {
      node.pos.x += Math.sin(t.current * 0.7) * delta * 0.03;
      node.pos.y += Math.cos(t.current * 0.5) * delta * 0.04;
      node.pos.z += Math.sin(t.current * 0.6) * delta * 0.03;
    }

    // Lerp to target
    node.pos.lerp(node.targetPos, delta * 1.5);

    if (meshRef.current) {
      meshRef.current.position.copy(node.pos);
      // Pulse glow for highlighted
      if (highlighted && glowRef.current) {
        const s = 1 + Math.sin(t.current * 3) * 0.15;
        glowRef.current.scale.setScalar(s * 1.6);
      }
    }
  });

  const opacity = faded ? 0.1 : highlighted ? 1.0 : 0.78;
  const emissive = highlighted ? baseColor.clone().multiplyScalar(0.5) : new THREE.Color(0, 0, 0);

  return (
    <group>
      {/* Glow halo for highlighted */}
      {highlighted && (
        <mesh ref={glowRef} position={node.pos.clone()}>
          <sphereGeometry args={[radius * 1.6, 12, 12]} />
          <meshBasicMaterial color={baseColor} transparent opacity={0.18} depthWrite={false} />
        </mesh>
      )}
      {/* Main sphere */}
      <mesh ref={meshRef} onClick={onClick} position={node.pos.clone()}>
        <sphereGeometry args={[radius, 24, 24]} />
        <meshStandardMaterial
          color={baseColor}
          emissive={emissive}
          emissiveIntensity={highlighted ? 0.6 : 0}
          transparent
          opacity={opacity}
          roughness={0.4}
          metalness={0.2}
        />
      </mesh>
      {/* Label */}
      {(node.type === 'department' || highlighted) && (
        <Billboard follow position={[node.pos.x, node.pos.y + radius + 0.25, node.pos.z]}>
          <Text
            fontSize={node.type === 'department' ? 0.28 : 0.18}
            color={highlighted ? '#3E1F0D' : '#5A2D12'}
            anchorX="center"
            anchorY="bottom"
            outlineWidth={0.02}
            outlineColor="#FBF4E4"
            maxWidth={3}
          >
            {node.label.length > 22 ? node.label.slice(0, 20) + '…' : node.label}
          </Text>
        </Billboard>
      )}
    </group>
  );
}

// ─── Links (lines between nodes) ──────────────────────────────────────────────
function GraphLinks({ links, faded }: { links: LinkData[]; faded: boolean }) {
  const geoRef = useRef<THREE.BufferGeometry>(null!);
  const matRef = useRef<THREE.LineBasicMaterial>(null!);

  useFrame(() => {
    if (!geoRef.current) return;
    const positions: number[] = [];
    links.forEach(({ a, b }) => {
      positions.push(a.pos.x, a.pos.y, a.pos.z);
      positions.push(b.pos.x, b.pos.y, b.pos.z);
    });
    const arr = new Float32Array(positions);
    geoRef.current.setAttribute('position', new THREE.Float32BufferAttribute(arr, 3));
    if (matRef.current) matRef.current.opacity = faded ? 0.05 : 0.18;
  });

  const initPositions = useMemo(() => {
    const arr: number[] = [];
    links.forEach(({ a, b }) => {
      arr.push(a.pos.x, a.pos.y, a.pos.z, b.pos.x, b.pos.y, b.pos.z);
    });
    return new Float32Array(arr);
  }, [links]);

  return (
    <lineSegments>
      <bufferGeometry ref={geoRef} onUpdate={self => {
        self.setAttribute('position', new THREE.Float32BufferAttribute(initPositions, 3));
      }} />
      <lineBasicMaterial ref={matRef} color="#C9964F" transparent opacity={faded ? 0.05 : 0.18} />
    </lineSegments>
  );
}

// ─── Camera auto-rotate + zoom-to-highlight ────────────────────────────────────
function CameraController({ hasQuery }: { hasQuery: boolean }) {
  const { camera } = useThree();
  useFrame((_, delta) => {
    if (!hasQuery) {
      // Slow orbital rotation
      const angle = Date.now() * 0.00005;
      const r = 28;
      camera.position.x = Math.sin(angle) * r;
      camera.position.z = Math.cos(angle) * r;
      camera.position.y = 8 + Math.sin(angle * 0.4) * 4;
      camera.lookAt(0, 0, 0);
    }
  });
  return null;
}

// ─── Main 3D scene ────────────────────────────────────────────────────────────
function Scene({
  faculty,
  highlightIds,
  onSelectFaculty,
}: {
  faculty: Faculty[];
  highlightIds: Set<string>;
  onSelectFaculty: (f: Faculty) => void;
}) {
  const hasQuery = highlightIds.size > 0;
  const { nodes, links } = useMemo(() => buildGraph(faculty, highlightIds), [faculty]);

  // When highlighted, move those nodes toward centre, rest away
  useEffect(() => {
    const spread = 18;
    nodes.forEach(n => {
      if (hasQuery) {
        if (n.type === 'faculty' && highlightIds.has(n.id)) {
          // Converge highlighted into a tight cluster
          const idx = Array.from(highlightIds).indexOf(n.id);
          const angle = (idx / highlightIds.size) * Math.PI * 2;
          n.targetPos.set(Math.cos(angle) * 4, Math.sin(angle) * 1.5, Math.sin(angle) * 4);
        } else if (n.type === 'faculty') {
          // Push non-highlighted outward
          n.targetPos.set(
            (Math.random() - 0.5) * spread,
            (Math.random() - 0.5) * spread * 0.6,
            (Math.random() - 0.5) * spread,
          );
        }
      } else {
        // Reset to random positions
        n.targetPos.set(
          (Math.random() - 0.5) * 22,
          (Math.random() - 0.5) * 14,
          (Math.random() - 0.5) * 22,
        );
      }
    });
  }, [highlightIds, hasQuery, nodes]);

  return (
    <>
      <CameraController hasQuery={hasQuery} />
      <ambientLight intensity={0.7} />
      <pointLight position={[15, 15, 15]} intensity={1.2} color="#fffbe6" />
      <pointLight position={[-15, -10, -10]} intensity={0.5} color="#C9964F" />

      <GraphLinks links={links} faded={hasQuery} />

      {nodes.map(node => {
        const isHighlighted = node.type === 'faculty' && highlightIds.has(node.id);
        const isFaded = hasQuery && !isHighlighted && node.type !== 'department';
        return (
          <GraphNode
            key={node.id}
            node={node}
            highlighted={isHighlighted}
            faded={isFaded}
            onClick={() => {
              if (node.faculty) onSelectFaculty(node.faculty);
            }}
          />
        );
      })}
    </>
  );
}

// ─── Exported wrapper ─────────────────────────────────────────────────────────
interface Props {
  faculty: Faculty[];
  highlightIds: Set<string>;
  onSelectFaculty: (f: Faculty) => void;
}

export default function Graph3D({ faculty, highlightIds, onSelectFaculty }: Props) {
  return (
    <div className="relative w-full rounded-2xl overflow-hidden"
      style={{ height: 560, border: '1px solid rgba(201,150,79,0.2)', background: 'linear-gradient(135deg, #FBF4E4 0%, #F0E2CB 100%)' }}>
      <Canvas camera={{ position: [0, 8, 28], fov: 55 }} dpr={[1, 2]}>
        <Scene faculty={faculty} highlightIds={highlightIds} onSelectFaculty={onSelectFaculty} />
        <OrbitControls
          enablePan={false}
          minDistance={8}
          maxDistance={45}
          autoRotate={highlightIds.size === 0}
          autoRotateSpeed={0.4}
        />
      </Canvas>

      {/* Dept legend */}
      <div className="absolute top-4 left-4 flex flex-wrap gap-2 pointer-events-none">
        {Object.entries(DEPT_COLORS).map(([dept, color]) => (
          <span key={dept} className="flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-full"
            style={{ background: 'rgba(251,244,228,0.9)', border: `1px solid ${color}50`, color: '#3E1F0D' }}>
            <span className="w-2 h-2 rounded-full" style={{ background: color }} />
            {dept}
          </span>
        ))}
      </div>

      <p className="absolute bottom-4 right-4 text-xs pointer-events-none" style={{ color: '#A47242' }}>
        Drag · Scroll to zoom · Click faculty node
      </p>
    </div>
  );
}
