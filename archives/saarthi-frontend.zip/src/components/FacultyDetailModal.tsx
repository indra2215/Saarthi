'use client';

import { useState, useEffect } from 'react';
import { Faculty, Availability, Slot } from '@/types';
import Image from 'next/image';

interface Props {
  faculty: Faculty;
  onClose: () => void;
  onBook: () => void;
}

export default function FacultyDetailModal({ faculty: f, onClose, onBook }: Props) {
  const [avail, setAvail] = useState<Availability | null>(null);
  const [tab, setTab] = useState<'profile' | 'projects' | 'topics'>('profile');

  useEffect(() => {
    fetch(`/api/availability?faculty_id=${f.chunk_id}`)
      .then(r => r.json())
      .then(setAvail);
  }, [f.chunk_id]);

  const freeSlots = avail?.slots.filter(s => !s.is_booked) || [];

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-box w-full" style={{ maxWidth: 640 }} onClick={e => e.stopPropagation()}>
        {/* Header */}
        <div className="flex items-start justify-between mb-5">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-full flex items-center justify-center text-3xl flex-shrink-0"
              style={{ background: 'rgba(201,150,79,0.1)', border: '2px solid rgba(201,150,79,0.3)' }}>
              {f.photo_url ? (
                <Image src={f.photo_url} alt={f.faculty_name} width={64} height={64}
                  className="w-16 h-16 rounded-full object-cover" />
              ) : (
                <span>{f.emoji}</span>
              )}
            </div>
            <div>
              <h2 className="text-xl font-bold leading-tight" style={{ fontFamily: 'Outfit, sans-serif', color: '#3E1F0D' }}>
                {f.faculty_name}
              </h2>
              <p className="text-sm" style={{ color: '#8A5A2B' }}>{f.designation}</p>
              <p className="text-xs" style={{ color: '#A47242' }}>{f.department}</p>
              <div className="flex flex-wrap gap-1.5 mt-2">
                {f.is_phd && <span className="tag tag-green" style={{ fontSize: 10 }}>PhD</span>}
                {f.is_hod && <span className="tag tag-gold" style={{ fontSize: 10 }}>HOD</span>}
                {f.google_scholar?.has_profile && (
                  <a href={f.google_scholar.profile_url!} target="_blank" rel="noopener noreferrer"
                    className="tag tag-blue" style={{ fontSize: 10 }}>📚 Scholar Profile</a>
                )}
                {f.linkedin?.has_profile && (
                  <a href={f.linkedin.profile_url!} target="_blank" rel="noopener noreferrer"
                    className="tag" style={{ fontSize: 10, background: 'rgba(10,102,194,0.1)', color: '#0a66c2', border: '1px solid rgba(10,102,194,0.2)' }}>
                    in LinkedIn
                  </a>
                )}
              </div>
            </div>
          </div>
          <button onClick={onClose} className="text-lg p-1 rounded-lg hover:bg-cream-100 transition-colors"
            style={{ color: '#8A5A2B' }}>✕</button>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 mb-4 p-1 rounded-xl" style={{ background: 'rgba(201,150,79,0.1)' }}>
          {(['profile', 'projects', 'topics'] as const).map(t => (
            <button key={t} onClick={() => setTab(t)}
              className="flex-1 py-1.5 text-xs font-medium rounded-lg capitalize transition-all"
              style={{
                background: tab === t ? 'white' : 'transparent',
                color: tab === t ? '#5A2D12' : '#A47242',
                boxShadow: tab === t ? '0 1px 6px rgba(62,31,13,0.08)' : 'none',
              }}>
              {t === 'profile' ? '👤 Profile' : t === 'projects' ? '🚀 Projects' : '🔬 Research'}
            </button>
          ))}
        </div>

        {/* Tab content */}
        <div className="overflow-y-auto" style={{ maxHeight: '45vh' }}>
          {tab === 'profile' && (
            <div className="animate-fadeIn">
              <div className="mb-4 p-4 rounded-xl" style={{ background: 'rgba(201,150,79,0.06)', border: '1px solid rgba(201,150,79,0.15)' }}>
                <p className="text-xs leading-relaxed" style={{ color: '#5A2D12' }}>
                  {f.detailed_research_profile}
                </p>
              </div>
              <div className="grid grid-cols-2 gap-3 mb-4 text-xs">
                <div className="p-3 rounded-xl" style={{ background: 'rgba(255,255,255,0.7)', border: '1px solid rgba(201,150,79,0.15)' }}>
                  <div className="font-medium mb-1" style={{ color: '#8A5A2B' }}>Qualification</div>
                  <div style={{ color: '#3E1F0D' }}>{f.qualification}</div>
                </div>
                <div className="p-3 rounded-xl" style={{ background: 'rgba(255,255,255,0.7)', border: '1px solid rgba(201,150,79,0.15)' }}>
                  <div className="font-medium mb-1" style={{ color: '#8A5A2B' }}>Academic Level</div>
                  <div style={{ color: '#3E1F0D' }}>{f.rag_metadata.academic_level}</div>
                </div>
              </div>
              {/* Availability preview */}
              <div>
                <h4 className="text-xs font-semibold mb-2" style={{ color: '#5A2D12' }}>
                  🗓 Available Slots ({freeSlots.length} open)
                </h4>
                <div className="flex flex-wrap gap-2">
                  {freeSlots.slice(0, 3).map((s: Slot) => (
                    <span key={s.slot_id} className="tag tag-green" style={{ fontSize: 11 }}>{s.time}</span>
                  ))}
                  {freeSlots.length === 0 && (
                    <span className="text-xs" style={{ color: '#A47242' }}>No open slots at the moment</span>
                  )}
                </div>
              </div>
            </div>
          )}

          {tab === 'projects' && (
            <div className="animate-fadeIn space-y-3">
              {f.projects && f.projects.length > 0 ? (
                f.projects.map((p, i) => (
                  <div key={i} className="p-4 rounded-xl" style={{ background: 'rgba(255,255,255,0.8)', border: '1px solid rgba(201,150,79,0.15)' }}>
                    <h4 className="font-semibold text-sm mb-1" style={{ color: '#3E1F0D', fontFamily: 'Outfit, sans-serif' }}>
                      {p.title}
                    </h4>
                    <p className="text-xs mb-2" style={{ color: '#8A5A2B' }}>
                      <span className="font-medium">Role:</span> {p.role} · <span className="font-medium">Domain:</span> {p.domain}
                    </p>
                    <p className="text-xs mb-2 leading-relaxed" style={{ color: '#5A2D12' }}>{p.summary}</p>
                    <div className="flex flex-wrap gap-1">
                      {p.technologies.map(tech => (
                        <span key={tech} className="tag tag-gold" style={{ fontSize: 10 }}>{tech}</span>
                      ))}
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-xs text-center py-8" style={{ color: '#A47242' }}>No project data available</p>
              )}
            </div>
          )}

          {tab === 'topics' && (
            <div className="animate-fadeIn">
              <div className="mb-4">
                <h4 className="text-xs font-semibold mb-2" style={{ color: '#5A2D12' }}>Stated Research Areas</h4>
                <div className="flex flex-wrap gap-2">
                  {f.stated_topics.map(t => (
                    <span key={t} className="tag tag-gold">{t}</span>
                  ))}
                </div>
              </div>
              <hr className="section-divider" />
              <div>
                <h4 className="text-xs font-semibold mb-2" style={{ color: '#5A2D12' }}>
                  Inferred Topics <span style={{ color: '#A47242', fontWeight: 400 }}>(AI-derived)</span>
                </h4>
                <div className="space-y-2">
                  {(f.inferred_topics || []).map((t, i) => (
                    <div key={i} className="flex items-center justify-between p-2.5 rounded-lg"
                      style={{ background: 'rgba(255,255,255,0.7)', border: '1px solid rgba(201,150,79,0.12)' }}>
                      <span className="text-xs font-medium" style={{ color: '#3E1F0D' }}>{t.topic}</span>
                      <div className="flex items-center gap-2">
                        <div className="w-16 h-1.5 rounded-full overflow-hidden" style={{ background: 'rgba(201,150,79,0.2)' }}>
                          <div className="h-full rounded-full" style={{ width: `${t.confidence * 100}%`, background: 'linear-gradient(90deg, #C9964F, #8A5A2B)' }} />
                        </div>
                        <span className="text-xs" style={{ color: '#A47242' }}>{Math.round(t.confidence * 100)}%</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              <hr className="section-divider" />
              <div>
                <h4 className="text-xs font-semibold mb-2" style={{ color: '#5A2D12' }}>Keywords</h4>
                <div className="flex flex-wrap gap-1.5">
                  {f.rag_metadata.tokens.map(tok => (
                    <span key={tok} className="tag tag-brown" style={{ fontSize: 10 }}>{tok}</span>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Book button */}
        <hr className="section-divider" />
        <button className="btn-primary w-full justify-center" onClick={onBook}>
          📅 Book a Meeting with {f.faculty_name.split(' ').slice(-1)[0]}
        </button>
      </div>
    </div>
  );
}
