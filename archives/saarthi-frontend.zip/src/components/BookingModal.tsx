'use client';

import { useState, useEffect } from 'react';
import { Faculty, Availability } from '@/types';

interface Props {
  faculty: Faculty;
  onClose: () => void;
}

export default function BookingModal({ faculty: f, onClose }: Props) {
  const [avail, setAvail] = useState<Availability | null>(null);
  const [selectedSlot, setSelectedSlot] = useState('');
  const [form, setForm] = useState({
    student_name: '',
    student_roll: '',
    student_email: '',
    project_title: '',
    project_description: '',
  });
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    fetch(`/api/availability?faculty_id=${f.chunk_id}`)
      .then(r => r.json())
      .then(setAvail);
  }, [f.chunk_id]);

  const freeSlots = avail?.slots.filter(s => !s.is_booked) || [];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSlot) { setError('Please select a time slot.'); return; }
    setSubmitting(true);
    setError('');
    try {
      const res = await fetch('/api/connections', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          faculty_id: f.chunk_id,
          faculty_name: f.faculty_name,
          department_code: f.department_code,
          ...form,
          requested_slot: selectedSlot,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setSuccess(`✅ Meeting request sent! Your request ID is ${data.request_id}`);
      } else {
        setError('Something went wrong. Please try again.');
      }
    } finally {
      setSubmitting(false);
    }
  };

  if (success) {
    return (
      <div className="modal-overlay" onClick={onClose}>
        <div className="modal-box text-center" onClick={e => e.stopPropagation()} style={{ maxWidth: 440 }}>
          <div className="text-5xl mb-4">🎉</div>
          <h3 className="text-xl font-bold mb-2" style={{ fontFamily: 'Outfit, sans-serif', color: '#3E1F0D' }}>
            Request Sent!
          </h3>
          <p className="text-sm mb-4" style={{ color: '#5A2D12' }}>{success}</p>
          <p className="text-xs mb-6" style={{ color: '#A47242' }}>
            {f.faculty_name} will review and confirm your meeting. You'll be notified at {form.student_email}.
          </p>
          <button className="btn-primary w-full justify-center" onClick={onClose}>Done</button>
        </div>
      </div>
    );
  }

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-box" style={{ maxWidth: 560 }} onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-5">
          <div>
            <h2 className="text-lg font-bold" style={{ fontFamily: 'Outfit, sans-serif', color: '#3E1F0D' }}>
              Book Meeting
            </h2>
            <p className="text-sm" style={{ color: '#8A5A2B' }}>with {f.faculty_name}</p>
          </div>
          <button onClick={onClose} style={{ color: '#8A5A2B' }}>✕</button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Slot selection */}
          <div>
            <label className="block text-xs font-semibold mb-2" style={{ color: '#5A2D12' }}>
              Select Time Slot *
            </label>
            {freeSlots.length === 0 ? (
              <p className="text-xs p-3 rounded-xl" style={{ background: 'rgba(239,68,68,0.08)', color: '#991b1b', border: '1px solid rgba(239,68,68,0.2)' }}>
                No available slots. Check back later.
              </p>
            ) : (
              <div className="grid grid-cols-1 gap-2">
                {freeSlots.map(s => (
                  <button
                    key={s.slot_id}
                    type="button"
                    onClick={() => setSelectedSlot(s.time)}
                    className="text-left p-3 rounded-xl text-sm transition-all"
                    style={{
                      background: selectedSlot === s.time ? 'rgba(201,150,79,0.15)' : 'rgba(255,255,255,0.7)',
                      border: `1.5px solid ${selectedSlot === s.time ? '#C9964F' : 'rgba(201,150,79,0.2)'}`,
                      color: '#3E1F0D',
                    }}>
                    {selectedSlot === s.time ? '✓ ' : '📅 '}{s.time}
                  </button>
                ))}
              </div>
            )}
          </div>

          <hr className="section-divider" />

          {/* Student info */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold mb-1" style={{ color: '#5A2D12' }}>Full Name *</label>
              <input required className="search-input" style={{ padding: '9px 14px', fontSize: 13 }}
                placeholder="Your full name"
                value={form.student_name}
                onChange={e => setForm({ ...form, student_name: e.target.value })} />
            </div>
            <div>
              <label className="block text-xs font-semibold mb-1" style={{ color: '#5A2D12' }}>Roll Number *</label>
              <input required className="search-input" style={{ padding: '9px 14px', fontSize: 13 }}
                placeholder="e.g. 245522748012"
                value={form.student_roll}
                onChange={e => setForm({ ...form, student_roll: e.target.value })} />
            </div>
          </div>
          <div>
            <label className="block text-xs font-semibold mb-1" style={{ color: '#5A2D12' }}>Email *</label>
            <input required type="email" className="search-input" style={{ padding: '9px 14px', fontSize: 13 }}
              placeholder="yourname@kmec.edu.in"
              value={form.student_email}
              onChange={e => setForm({ ...form, student_email: e.target.value })} />
          </div>
          <div>
            <label className="block text-xs font-semibold mb-1" style={{ color: '#5A2D12' }}>Project / Research Title *</label>
            <input required className="search-input" style={{ padding: '9px 14px', fontSize: 13 }}
              placeholder="e.g. AI-Powered Traffic Management System"
              value={form.project_title}
              onChange={e => setForm({ ...form, project_title: e.target.value })} />
          </div>
          <div>
            <label className="block text-xs font-semibold mb-1" style={{ color: '#5A2D12' }}>Brief Description *</label>
            <textarea required className="search-input" style={{ padding: '9px 14px', fontSize: 13, height: 90, resize: 'none' }}
              placeholder="Describe your project idea and what guidance you're looking for…"
              value={form.project_description}
              onChange={e => setForm({ ...form, project_description: e.target.value })} />
          </div>

          {error && <p className="text-xs p-3 rounded-xl" style={{ background: 'rgba(239,68,68,0.08)', color: '#991b1b', border: '1px solid rgba(239,68,68,0.2)' }}>{error}</p>}

          <button
            type="submit"
            className="btn-primary w-full justify-center"
            disabled={submitting || freeSlots.length === 0}>
            {submitting ? '⏳ Sending…' : '📤 Send Meeting Request'}
          </button>
        </form>
      </div>
    </div>
  );
}
