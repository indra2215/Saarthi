export interface GoogleScholar {
  has_profile: boolean;
  profile_url: string | null;
  status: string;
  matched_scholar_name: string | null;
}

export interface LinkedIn {
  has_profile: boolean;
  profile_url: string | null;
  status: string;
  projects?: Project[];
}

export interface RagMetadata {
  tokens: string[];
  department_code: string;
  academic_level: string;
  embedding_text: string;
}

export interface InferredTopic {
  topic: string;
  confidence: number;
  source_passage_id: string;
  source_snippet: string;
}

export interface Project {
  title: string;
  role: string;
  domain: string;
  technologies: string[];
  summary: string;
}

export interface Faculty {
  chunk_id: string;
  serial_no: number;
  section_id: number;
  faculty_name: string;
  normalized_name: string;
  department: string;
  department_code: string;
  designation: string;
  qualification: string;
  is_phd: boolean;
  is_hod: boolean;
  google_scholar: GoogleScholar;
  linkedin?: LinkedIn;
  primary_domain: string;
  research_areas: string[];
  detailed_research_profile: string;
  rag_metadata: RagMetadata;
  photo_url: string | null;
  emoji: string;
  stated_topics: string[];
  inferred_topics: InferredTopic[];
  aliases: string[];
  projects?: Project[];
  similarity_score?: number;
}

export interface Slot {
  slot_id: string;
  time: string;
  is_booked: boolean;
}

export interface Availability {
  faculty_id: string;
  faculty_name: string;
  department_code: string;
  slots: Slot[];
}

export interface StatusStep {
  step: string;
  timestamp: string;
  note: string;
}

export interface Connection {
  request_id: string;
  faculty_id: string;
  faculty_name: string;
  department_code: string;
  student_name: string;
  student_roll: string;
  student_email: string;
  project_title: string;
  project_description: string;
  requested_slot: string;
  status: string;
  suggested_time?: string;
  status_timeline: StatusStep[];
}
