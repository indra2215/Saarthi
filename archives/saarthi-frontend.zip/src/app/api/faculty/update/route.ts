import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';
import { Faculty } from '@/types';
import { invalidateFacultyCache } from '@/lib/data';

const enrichedPath = path.join(process.cwd(), 'data', 'faculty.enriched.json');

// PATCH — update editable fields of a faculty profile
export async function PATCH(req: NextRequest) {
  const body = await req.json();
  const { faculty_id, updates } = body;

  if (!faculty_id || !updates) {
    return NextResponse.json({ success: false, error: 'faculty_id and updates required' }, { status: 400 });
  }

  const raw = fs.readFileSync(enrichedPath, 'utf-8');
  const faculty: Faculty[] = JSON.parse(raw);
  const idx = faculty.findIndex((f) => f.chunk_id === faculty_id);

  if (idx === -1) {
    return NextResponse.json({ success: false, error: 'Faculty not found' }, { status: 404 });
  }

  // Only allow editing safe fields
  const allowedFields = [
    'designation',
    'qualification',
    'primary_domain',
    'research_areas',
    'detailed_research_profile',
    'stated_topics',
  ];

  allowedFields.forEach((field) => {
    if (updates[field] !== undefined) {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      (faculty[idx] as any)[field] = updates[field];
    }
  });

  // If research_areas updated, also update stated_topics to match
  if (updates.research_areas) {
    faculty[idx].stated_topics = [
      faculty[idx].primary_domain,
      ...updates.research_areas,
    ].filter(Boolean);
  }

  // Support updating LinkedIn and Google Scholar URLs
  if (updates.linkedin_url !== undefined) {
    if (updates.linkedin_url.trim()) {
      faculty[idx].linkedin = {
        has_profile: true,
        profile_url: updates.linkedin_url.trim(),
        status: 'ACTIVE',
        projects: faculty[idx].linkedin?.projects || faculty[idx].projects || [],
      };
    } else {
      faculty[idx].linkedin = {
        has_profile: false,
        profile_url: null,
        status: 'NOT_AVAILABLE',
      };
    }
  }

  if (updates.scholar_url !== undefined) {
    if (updates.scholar_url.trim()) {
      faculty[idx].google_scholar = {
        has_profile: true,
        profile_url: updates.scholar_url.trim(),
        status: 'ACTIVE',
        matched_scholar_name: faculty[idx].google_scholar?.matched_scholar_name || faculty[idx].faculty_name,
      };
    } else {
      faculty[idx].google_scholar = {
        has_profile: false,
        profile_url: null,
        status: 'NOT_FOUND',
        matched_scholar_name: null,
      };
    }
  }

  fs.writeFileSync(enrichedPath, JSON.stringify(faculty, null, 2));
  invalidateFacultyCache();   // clear in-memory cache so next API call reads fresh data
  return NextResponse.json({ success: true, faculty: faculty[idx] });
}
