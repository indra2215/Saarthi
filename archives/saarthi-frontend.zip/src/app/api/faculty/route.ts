import { NextRequest, NextResponse } from 'next/server';
import { getAllFaculty } from '@/lib/data';
import { semanticSearchFaculty } from '@/lib/vectorSearch';

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const query = searchParams.get('q') || '';
  const dept = searchParams.get('dept') || '';
  const phd = searchParams.get('phd') || '';
  const scholar = searchParams.get('scholar') || '';

  let results = query ? await semanticSearchFaculty(query) : getAllFaculty();

  if (dept) {
    results = results.filter((f) => f.department_code === dept);
  }
  if (phd === 'true') {
    results = results.filter((f) => f.is_phd);
  }
  if (scholar === 'true') {
    results = results.filter((f) => f.google_scholar?.has_profile);
  }

  return NextResponse.json(results);
}
