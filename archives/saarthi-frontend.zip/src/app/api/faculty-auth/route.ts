import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

const authPath = path.join(process.cwd(), 'data', 'faculty_auth.json');

export async function POST(req: NextRequest) {
  const { username, password } = await req.json();
  const raw = fs.readFileSync(authPath, 'utf-8');
  const authDb: Record<string, { faculty_id: string; username: string; password: string; faculty_name: string; department_code: string }> = JSON.parse(raw);

  const match = Object.values(authDb).find(
    (v) => v.username === username.toLowerCase().trim() && v.password === password.trim()
  );

  if (match) {
    return NextResponse.json({
      success: true,
      faculty_id: match.faculty_id,
      faculty_name: match.faculty_name,
      department_code: match.department_code,
    });
  }

  return NextResponse.json({ success: false, error: 'Invalid credentials' }, { status: 401 });
}
