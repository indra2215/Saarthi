import { NextRequest, NextResponse } from 'next/server';
import { semanticSearchFaculty } from '@/lib/vectorSearch';

export async function POST(req: NextRequest) {
  try {
    const { query, project_description } = await req.json();
    const promptQuery = (query || project_description || '').trim();

    if (!promptQuery) {
      return NextResponse.json({ success: false, error: 'Query or project description required' }, { status: 400 });
    }

    // 1. Retrieval Phase: Retrieve top grounded faculty chunks via semantic vector search
    const candidates = await semanticSearchFaculty(promptQuery);
    const topFaculty = candidates.slice(0, 4);

    if (topFaculty.length === 0) {
      return NextResponse.json({
        success: true,
        advice: 'No directly matching faculty chunks found in the database. Please try broadening your research topic.',
        faculty: [],
      });
    }

    // 2. Augmentation Phase: Build grounded context from retrieved chunks
    const facultyContext = topFaculty
      .map(
        (f, idx) => `
[Faculty #${idx + 1}]
- Chunk ID: ${f.chunk_id}
- Name: ${f.faculty_name} (${f.designation})
- Department: ${f.department} (${f.department_code})
- Qualification: ${f.qualification} (PhD: ${f.is_phd ? 'Yes' : 'No'})
- Primary Domain: ${f.primary_domain}
- Core Research Areas: ${f.research_areas.join(', ')}
- Stated Research Topics: ${f.stated_topics.join(', ')}
- Inferred Topics: ${(f.inferred_topics || []).map((t) => t.topic).join(', ')}
- Google Scholar: ${f.google_scholar?.has_profile ? f.google_scholar.profile_url : 'None'}
- Research Profile Summary: ${f.detailed_research_profile}
`
      )
      .join('\n---\n');

    const apiKey = process.env.GEMINI_API_KEY || 'AQ.Ab8RN6KM27--cpceBInW3dWkeehL4XLLHjxys0SIyTnQTVWUfg';

    // 3. Generation Phase: Ask Gemini 3.8 Flash to synthesize grounded guidance
    const systemPrompt = `You are SAARTHI AI, the official academic research advisor for Keshav Memorial Engineering College (KMEC).
Your job is to provide grounded, highly actionable mentorship guidance to students based SOLELY on the retrieved faculty chunks provided below.

Strict Guidelines:
1. Recommend the 1 or 2 best faculty mentors from the provided chunks and explain explicitly why their research areas, publications, or domain make them the ideal match for the student's idea.
2. Outline 2-3 specific, high-impact research angles or sub-problems they can explore together.
3. Suggest a concise 1-sentence meeting pitch the student can use when requesting a booking slot.
4. Ground every statement in the provided chunks. Do NOT hallucinate names, credentials, or departments outside these chunks.
5. Keep your tone encouraging, academically sharp, and structured with clean markdown.`;

    const userContent = `Student's Research Interest / Project Idea:
"${promptQuery}"

Verified KMEC Faculty Chunks (Retrieved via Dense Vector Embeddings):
${facultyContext}

Please provide your AI Advisor recommendation.`;

    const geminiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent?key=${apiKey}`;

    const geminiRes = await fetch(geminiUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [
          {
            parts: [
              { text: `${systemPrompt}\n\n${userContent}` },
            ],
          },
        ],
        generationConfig: {
          temperature: 0.3,
          maxOutputTokens: 900,
        },
      }),
    });

    if (!geminiRes.ok) {
      const errText = await geminiRes.text();
      console.error('Gemini advisor error:', errText);
      return NextResponse.json({
        success: false,
        error: 'Failed to generate AI advice',
        faculty: topFaculty,
      }, { status: 500 });
    }

    const geminiData = await geminiRes.json();
    const advice =
      geminiData.candidates?.[0]?.content?.parts?.[0]?.text ||
      'Unable to synthesize guidance at this time.';

    return NextResponse.json({
      success: true,
      advice,
      faculty: topFaculty,
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}
