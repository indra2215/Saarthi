import { NextRequest, NextResponse } from 'next/server';
import { getAvailability } from '@/lib/data';

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const facultyId = searchParams.get('faculty_id');
  const avail = getAvailability();

  if (facultyId) {
    return NextResponse.json(avail[facultyId] || null);
  }
  return NextResponse.json(avail);
}
