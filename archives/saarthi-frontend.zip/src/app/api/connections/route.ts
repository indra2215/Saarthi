import { NextRequest, NextResponse } from 'next/server';
import { getConnections, addConnection } from '@/lib/data';
import { Connection } from '@/types';
import fs from 'fs';
import path from 'path';

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const facultyId = searchParams.get('faculty_id');
  const studentRoll = searchParams.get('student_roll');
  const connections = getConnections();

  if (facultyId) return NextResponse.json(connections.filter((c) => c.faculty_id === facultyId));
  if (studentRoll) return NextResponse.json(connections.filter((c) => c.student_roll === studentRoll));
  return NextResponse.json(connections);
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  const conn: Connection = {
    request_id: `REQ-${Date.now()}`,
    faculty_id: body.faculty_id,
    faculty_name: body.faculty_name,
    department_code: body.department_code,
    student_name: body.student_name,
    student_roll: body.student_roll,
    student_email: body.student_email,
    project_title: body.project_title,
    project_description: body.project_description,
    requested_slot: body.requested_slot,
    status: 'Pending professor approval',
    status_timeline: [
      {
        step: 'Requested',
        timestamp: new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' }),
        note: 'Initial slot request submitted.',
      },
    ],
  };
  addConnection(conn);
  return NextResponse.json({ success: true, request_id: conn.request_id });
}

// PATCH — update status of a connection (approve / reject / suggest time)
export async function PATCH(req: NextRequest) {
  const body = await req.json();
  const { request_id, status, note, suggested_time } = body;

  const dataPath = path.join(process.cwd(), 'data', 'connections.json');
  const raw = fs.readFileSync(dataPath, 'utf-8');
  const connections: Connection[] = JSON.parse(raw);

  const idx = connections.findIndex((c) => c.request_id === request_id);
  if (idx === -1) {
    return NextResponse.json({ success: false, error: 'Request not found' }, { status: 404 });
  }

  connections[idx].status = status;
  if (suggested_time) connections[idx].suggested_time = suggested_time;

  connections[idx].status_timeline.push({
    step: status,
    timestamp: new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' }),
    note: note || `Status updated to ${status}`,
  });

  fs.writeFileSync(dataPath, JSON.stringify(connections, null, 2));

  return NextResponse.json({ success: true });
}
