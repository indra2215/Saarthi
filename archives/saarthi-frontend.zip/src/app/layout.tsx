import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'SAARTHI — Faculty Research Discovery',
  description:
    'Discover KMEC faculty research expertise and connect with mentors for your academic projects. Search by topic, explore research graphs, and book meetings.',
  keywords: 'SAARTHI, faculty research, KMEC, research discovery, academic mentor, student connect',
  openGraph: {
    title: 'SAARTHI — Faculty Research Discovery',
    description: 'Find the right faculty mentor for your research project at KMEC.',
    type: 'website',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="icon" href="/saarthi-logo.png" type="image/png" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
      </head>
      <body>{children}</body>
    </html>
  );
}
