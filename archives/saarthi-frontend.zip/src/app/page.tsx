'use client';
import { useRouter } from 'next/navigation';
import Image from 'next/image';

export default function HomePage() {
  const router = useRouter();
  return (
    <main
      className="min-h-screen flex flex-col items-center justify-center relative overflow-hidden"
      style={{ background: 'linear-gradient(145deg, #FBF4E4 0%, #F3E6CC 50%, #EBDDBF 100%)' }}
    >
      {/* Background watermark logo — large, faded, centred */}
      <div
        className="absolute inset-0 flex items-center justify-center pointer-events-none select-none"
        style={{ zIndex: 0 }}
      >
        <Image
          src="/saarthi-logo.png"
          alt=""
          width={520}
          height={520}
          className="object-contain opacity-[0.06]"
          priority
        />
      </div>

      {/* Decorative radial glows */}
      <div
        className="absolute top-[-100px] right-[-100px] w-[380px] h-[380px] rounded-full pointer-events-none"
        style={{ background: 'radial-gradient(circle, rgba(201,150,79,0.18) 0%, transparent 70%)' }}
      />
      <div
        className="absolute bottom-[-80px] left-[-60px] w-[280px] h-[280px] rounded-full pointer-events-none"
        style={{ background: 'radial-gradient(circle, rgba(90,45,18,0.12) 0%, transparent 70%)' }}
      />

      {/* Main content */}
      <div className="relative z-10 flex flex-col items-center text-center px-6 animate-fadeIn">

        {/* Brand header — logo + wordmark side by side */}
        <div className="flex items-center gap-4 mb-3">
          <Image
            src="/saarthi-logo.png"
            alt="SAARTHI Logo"
            width={72}
            height={72}
            className="object-contain drop-shadow-md"
            priority
          />
          <div className="text-left">
            <h1
              className="text-5xl font-extrabold tracking-tight leading-none gradient-text"
              style={{ fontFamily: 'Outfit, sans-serif' }}
            >
              SAARTHI
            </h1>
            <p className="text-sm font-semibold tracking-widest uppercase mt-0.5" style={{ color: '#A47242', letterSpacing: '0.18em' }}>
              KMEC · Hyderabad
            </p>
          </div>
        </div>

        {/* Subtitle */}
        <p className="text-base font-medium mb-1 mt-2" style={{ color: '#5A2D12' }}>
          Faculty Research Discovery Assistant
        </p>
        <p className="text-sm max-w-md mb-10" style={{ color: '#A47242', lineHeight: 1.65 }}>
          Find the right faculty mentor for your research project — search by topic, explore the research universe, and book a meeting in seconds.
        </p>

        {/* Portal cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 w-full max-w-lg">
          {/* Student portal */}
          <button
            onClick={() => router.push('/student')}
            className="glass-card p-6 text-left group cursor-pointer border-none outline-none"
            style={{ borderRadius: 20 }}
          >
            <div className="text-4xl mb-3">🎓</div>
            <h2
              className="text-xl font-bold mb-1"
              style={{ fontFamily: 'Outfit, sans-serif', color: '#3E1F0D' }}
            >
              Student Portal
            </h2>
            <p className="text-sm" style={{ color: '#8A5A2B' }}>
              Search faculty, explore the 3D research universe &amp; book meetings
            </p>
            <div
              className="mt-4 flex items-center gap-1 text-xs font-semibold"
              style={{ color: '#C9964F' }}
            >
              Enter Portal
              <svg
                className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M9 5l7 7-7 7" />
              </svg>
            </div>
          </button>

          {/* Faculty portal */}
          <button
            onClick={() => router.push('/faculty/login')}
            className="glass-card p-6 text-left group cursor-pointer border-none outline-none"
            style={{ borderRadius: 20 }}
          >
            <div className="text-4xl mb-3">👨‍🏫</div>
            <h2
              className="text-xl font-bold mb-1"
              style={{ fontFamily: 'Outfit, sans-serif', color: '#3E1F0D' }}
            >
              Faculty Portal
            </h2>
            <p className="text-sm" style={{ color: '#8A5A2B' }}>
              Sign in to manage your availability &amp; review student requests
            </p>
            <div
              className="mt-4 flex items-center gap-1 text-xs font-semibold"
              style={{ color: '#C9964F' }}
            >
              Sign In
              <svg
                className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M9 5l7 7-7 7" />
              </svg>
            </div>
          </button>
        </div>

        {/* Stats strip */}
        <div className="mt-10 flex gap-8 text-center">
          {[
            { num: '131', label: 'Faculty Profiles' },
            { num: '5', label: 'Departments' },
            { num: '50+', label: 'Research Areas' },
          ].map(({ num, label }) => (
            <div key={label}>
              <div
                className="text-2xl font-bold gradient-text"
                style={{ fontFamily: 'Outfit, sans-serif' }}
              >
                {num}
              </div>
              <div className="text-xs mt-0.5" style={{ color: '#A47242' }}>{label}</div>
            </div>
          ))}
        </div>
      </div>
    </main>
  );
}
