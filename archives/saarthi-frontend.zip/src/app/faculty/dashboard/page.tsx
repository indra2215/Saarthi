'use client';

import { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import Image from 'next/image';
import { Faculty, Connection, Availability } from '@/types';

/* ─── Status styling ────────────────────────────────────────────────────────── */
const STATUS_META: Record<string, { cls: string; emoji: string }> = {
  'Accepted':                  { cls: 'status-accepted',  emoji: '✅' },
  'Pending professor approval': { cls: 'status-pending',   emoji: '🕐' },
  'Better time suggested':     { cls: 'status-suggested', emoji: '📅' },
  'Rejected':                  { cls: 'status-rejected',  emoji: '❌' },
};

/* ─── Session type ──────────────────────────────────────────────────────────── */
interface Session {
  faculty_id: string;
  faculty_name: string;
  department_code: string;
  logged_in_at: number;
}

/* ════════════════════════════════════════════════════════════════════════════ */
export default function FacultyDashboard() {
  const router = useRouter();
  const [session, setSession]           = useState<Session | null>(null);
  const [faculty, setFaculty]           = useState<Faculty | null>(null);
  const [connections, setConnections]   = useState<Connection[]>([]);
  const [avail, setAvail]               = useState<Availability | null>(null);
  const [activeTab, setActiveTab]       = useState<'requests' | 'availability' | 'profile' | 'edit'>('requests');
  const [loading, setLoading]           = useState(true);
  const [actionMsg, setActionMsg]       = useState('');

  /* ── Auth guard ── */
  useEffect(() => {
    const raw = localStorage.getItem('saarthi_faculty_session');
    if (!raw) { router.replace('/faculty/login'); return; }
    const sess: Session = JSON.parse(raw);
    if (Date.now() - sess.logged_in_at > 8 * 60 * 60 * 1000) {
      localStorage.removeItem('saarthi_faculty_session');
      router.replace('/faculty/login');
      return;
    }
    setSession(sess);
  }, [router]);

  /* ── Load data ── */
  const loadData = useCallback(async (facultyId: string) => {
    const [allFac, conns, av] = await Promise.all([
      fetch(`/api/faculty?q=${encodeURIComponent(facultyId)}`).then(r => r.json()),
      fetch(`/api/connections?faculty_id=${facultyId}`).then(r => r.json()),
      fetch(`/api/availability?faculty_id=${facultyId}`).then(r => r.json()),
    ]);
    const me = (allFac as Faculty[]).find(f => f.chunk_id === facultyId) || null;
    setFaculty(me);
    setConnections(conns);
    setAvail(av);
    setLoading(false);
  }, []);

  useEffect(() => {
    if (session) loadData(session.faculty_id);
  }, [session, loadData]);

  const handleLogout = () => {
    localStorage.removeItem('saarthi_faculty_session');
    router.push('/faculty/login');
  };

  /* ── Request action (approve / reject / suggest) ── */
  const updateRequest = async (
    request_id: string,
    status: string,
    note: string,
    suggested_time?: string
  ) => {
    const res = await fetch('/api/connections', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ request_id, status, note, suggested_time }),
    });
    if (res.ok) {
      setActionMsg(`✅ Request ${status.toLowerCase()}.`);
      setTimeout(() => setActionMsg(''), 3000);
      if (session) await loadData(session.faculty_id);   // refresh
    }
  };

  /* ─── Derived ─────────────────────────────────────────────────────────────── */
  if (loading || !session) {
    return (
      <div className="min-h-screen flex items-center justify-center"
        style={{ background: 'linear-gradient(145deg,#FBF4E4 0%,#F3E6CC 100%)' }}>
        <div className="text-center animate-fadeIn">
          <div className="w-12 h-12 border-4 rounded-full mx-auto mb-4 animate-spin"
            style={{ borderColor: 'rgba(201,150,79,0.2)', borderTopColor: '#C9964F' }} />
          <p className="text-sm" style={{ color: '#8A5A2B' }}>Loading your dashboard…</p>
        </div>
      </div>
    );
  }

  const freeSlots    = avail?.slots.filter(s => !s.is_booked) || [];
  const pendingCount = connections.filter(c => c.status === 'Pending professor approval').length;

  const tabs = [
    { key: 'requests' as const,     label: `📬 Requests${pendingCount > 0 ? ` (${pendingCount})` : ''}` },
    { key: 'availability' as const, label: '🗓 Availability' },
    { key: 'profile' as const,      label: '📋 My Profile' },
    { key: 'edit' as const,         label: '✏️ Edit Profile' },
  ];

  return (
    <div className="min-h-screen flex flex-col"
      style={{ background: 'linear-gradient(180deg,#FBF4E4 0%,#F7ECD6 100%)' }}>

      {/* ── Nav ── */}
      <nav className="nav-bar px-6 py-3 flex items-center justify-between">
        <button onClick={() => router.push('/')} className="flex items-center gap-2.5">
          <Image src="/saarthi-logo.png" alt="SAARTHI" width={34} height={34} className="object-contain" />
          <span className="font-bold text-lg gradient-text" style={{ fontFamily: 'Outfit, sans-serif' }}>SAARTHI</span>
        </button>
        <div className="flex items-center gap-3">
          <span className="text-sm font-medium hidden sm:block" style={{ color: '#5A2D12' }}>
            {faculty?.emoji} {session.faculty_name.split(' ').slice(-2).join(' ')}
          </span>
          <button onClick={handleLogout} className="btn-secondary text-xs py-1.5 px-3">🚪 Logout</button>
        </div>
      </nav>

      <div className="max-w-5xl mx-auto w-full px-4 py-6 animate-fadeIn">

        {/* ── Hero card ── */}
        <div className="glass-card p-5 mb-5 flex items-center gap-4 flex-wrap">
          <div className="text-5xl">{faculty?.emoji || '👨‍🏫'}</div>
          <div className="flex-1 min-w-0">
            <h2 className="text-xl font-bold truncate"
              style={{ fontFamily: 'Outfit, sans-serif', color: '#3E1F0D' }}>
              {faculty?.faculty_name}
            </h2>
            <p className="text-sm mt-0.5" style={{ color: '#8A5A2B' }}>
              {faculty?.designation} · {faculty?.department}
            </p>
            <p className="text-xs mt-0.5" style={{ color: '#A47242' }}>{faculty?.primary_domain}</p>
            <div className="flex flex-wrap gap-2 mt-2">
              {faculty?.is_phd  && <span className="tag tag-green  text-xs">PhD</span>}
              {faculty?.is_hod  && <span className="tag tag-gold   text-xs">HOD</span>}
              {faculty?.google_scholar?.has_profile && (
                <a href={faculty.google_scholar.profile_url!} target="_blank" rel="noopener noreferrer"
                  className="tag tag-blue text-xs">📚 Scholar ↗</a>
              )}
              {faculty?.linkedin?.has_profile && (
                <a href={faculty.linkedin.profile_url!} target="_blank" rel="noopener noreferrer"
                  className="tag text-xs"
                  style={{ background: 'rgba(10,102,194,0.1)', color: '#0a66c2', border: '1px solid rgba(10,102,194,0.2)' }}>
                  in LinkedIn ↗
                </a>
              )}
            </div>
          </div>

          {/* Stats */}
          <div className="flex gap-3 flex-shrink-0">
            <div className="p-3 rounded-xl text-center"
              style={{ background: pendingCount > 0 ? 'rgba(254,249,195,0.8)' : 'rgba(220,252,231,0.8)',
                       border: `1px solid ${pendingCount > 0 ? '#fef08a' : '#bbf7d0'}`, minWidth: 64 }}>
              <div className="text-2xl font-bold" style={{ color: pendingCount > 0 ? '#854d0e' : '#166534', fontFamily: 'Outfit, sans-serif' }}>
                {pendingCount}
              </div>
              <div className="text-xs" style={{ color: '#8A5A2B' }}>Pending</div>
            </div>
            <div className="p-3 rounded-xl text-center"
              style={{ background: 'rgba(219,234,254,0.8)', border: '1px solid #bfdbfe', minWidth: 64 }}>
              <div className="text-2xl font-bold" style={{ color: '#1e40af', fontFamily: 'Outfit, sans-serif' }}>
                {freeSlots.length}
              </div>
              <div className="text-xs" style={{ color: '#8A5A2B' }}>Free Slots</div>
            </div>
          </div>
        </div>

        {/* Action flash */}
        {actionMsg && (
          <div className="mb-4 p-3 rounded-xl text-sm animate-fadeIn"
            style={{ background: 'rgba(34,197,94,0.12)', color: '#166534', border: '1px solid #bbf7d0' }}>
            {actionMsg}
          </div>
        )}

        {/* ── Tabs ── */}
        <div className="flex gap-1 mb-5 p-1 rounded-xl flex-wrap"
          style={{ background: 'rgba(201,150,79,0.1)', width: 'fit-content' }}>
          {tabs.map(({ key, label }) => (
            <button key={key} onClick={() => setActiveTab(key)}
              className="px-4 py-1.5 text-xs font-medium rounded-lg transition-all"
              style={{
                background: activeTab === key ? 'white' : 'transparent',
                color:      activeTab === key ? '#5A2D12' : '#A47242',
                boxShadow:  activeTab === key ? '0 1px 6px rgba(62,31,13,0.08)' : 'none',
              }}>
              {label}
            </button>
          ))}
        </div>

        {/* ════════ REQUESTS TAB ════════ */}
        {activeTab === 'requests' && (
          <div className="space-y-4 animate-fadeIn">
            {connections.length === 0 ? (
              <div className="text-center py-16">
                <div className="text-5xl mb-3">📭</div>
                <p className="text-sm" style={{ color: '#A47242' }}>No student requests yet</p>
              </div>
            ) : (
              connections.map(conn => (
                <RequestCard
                  key={conn.request_id}
                  conn={conn}
                  onAction={updateRequest}
                />
              ))
            )}
          </div>
        )}

        {/* ════════ AVAILABILITY TAB ════════ */}
        {activeTab === 'availability' && (
          <div className="animate-fadeIn">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-4">
              {avail?.slots.map(slot => (
                <div key={slot.slot_id} className="glass-card p-4"
                  style={{ borderLeft: `3px solid ${slot.is_booked ? '#ef4444' : '#10b981'}`, opacity: slot.is_booked ? 0.7 : 1 }}>
                  <div className="flex items-center gap-2 mb-2">
                    <span>{slot.is_booked ? '🔴' : '🟢'}</span>
                    <span className="text-sm font-medium" style={{ color: '#3E1F0D' }}>{slot.time}</span>
                  </div>
                  <span className={`tag text-xs ${slot.is_booked ? 'status-rejected' : 'status-accepted'}`}
                    style={{ borderRadius: 20, padding: '3px 10px' }}>
                    {slot.is_booked ? 'Booked' : 'Available'}
                  </span>
                </div>
              ))}
            </div>
            <p className="text-xs" style={{ color: '#A47242' }}>
              💡 Custom slot management (adding/removing slots, marking leaves) coming in v2.
            </p>
          </div>
        )}

        {/* ════════ PROFILE TAB ════════ */}
        {activeTab === 'profile' && faculty && (
          <div className="space-y-4 animate-fadeIn">
            <div className="glass-card p-5">
              <h4 className="font-semibold mb-3" style={{ fontFamily: 'Outfit, sans-serif', color: '#3E1F0D' }}>
                Research Profile
              </h4>
              <p className="text-sm leading-relaxed" style={{ color: '#5A2D12' }}>
                {faculty.detailed_research_profile}
              </p>
            </div>
            <div className="glass-card p-5">
              <h4 className="font-semibold mb-3" style={{ fontFamily: 'Outfit, sans-serif', color: '#3E1F0D' }}>
                Research Areas
              </h4>
              <div className="flex flex-wrap gap-2">
                {faculty.stated_topics.map(t => (
                  <span key={t} className="tag tag-gold">{t}</span>
                ))}
              </div>
            </div>
            {faculty.projects && faculty.projects.length > 0 && (
              <div className="glass-card p-5">
                <h4 className="font-semibold mb-3" style={{ fontFamily: 'Outfit, sans-serif', color: '#3E1F0D' }}>
                  Projects &amp; Contributions
                </h4>
                <div className="space-y-3">
                  {faculty.projects.map((p, i) => (
                    <div key={i} className="p-4 rounded-xl"
                      style={{ background: 'rgba(255,255,255,0.7)', border: '1px solid rgba(201,150,79,0.12)' }}>
                      <p className="font-semibold text-sm" style={{ color: '#3E1F0D' }}>{p.title}</p>
                      <p className="text-xs mt-0.5 mb-2" style={{ color: '#8A5A2B' }}>{p.role} · {p.domain}</p>
                      <p className="text-xs leading-relaxed mb-2" style={{ color: '#5A2D12' }}>{p.summary}</p>
                      <div className="flex flex-wrap gap-1">
                        {p.technologies.map(t => (
                          <span key={t} className="tag tag-gold" style={{ fontSize: 10 }}>{t}</span>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* ════════ EDIT PROFILE TAB ════════ */}
        {activeTab === 'edit' && faculty && (
          <EditProfilePanel
            faculty={faculty}
            onSaved={(updated) => {
              setFaculty(updated);
              setActiveTab('profile');
              setActionMsg('✅ Profile updated successfully!');
              setTimeout(() => setActionMsg(''), 3000);
            }}
          />
        )}
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════════════════════
   Request card with Approve / Reject / Suggest time
══════════════════════════════════════════════════════════════════════════════ */
function RequestCard({
  conn,
  onAction,
}: {
  conn: Connection;
  onAction: (id: string, status: string, note: string, suggested?: string) => void;
}) {
  const [suggestMode, setSuggestMode] = useState(false);
  const [suggestedTime, setSuggestedTime] = useState('');
  const [busy, setBusy] = useState(false);

  const isPending = conn.status === 'Pending professor approval';
  const meta = STATUS_META[conn.status] || { cls: 'tag-gold', emoji: '❓' };

  const act = async (status: string, note: string, suggested?: string) => {
    setBusy(true);
    await onAction(conn.request_id, status, note, suggested);
    setBusy(false);
    setSuggestMode(false);
  };

  return (
    <div className="glass-card p-5">
      {/* Top row */}
      <div className="flex items-start justify-between gap-3 mb-3 flex-wrap">
        <div>
          <h4 className="font-bold text-base" style={{ fontFamily: 'Outfit, sans-serif', color: '#3E1F0D' }}>
            {conn.student_name}
          </h4>
          <p className="text-xs mt-0.5" style={{ color: '#8A5A2B' }}>
            Roll: {conn.student_roll} · {conn.student_email}
          </p>
        </div>
        <span className={`tag text-xs ${meta.cls}`}
          style={{ padding: '4px 12px', borderRadius: 20, flexShrink: 0 }}>
          {meta.emoji} {conn.status}
        </span>
      </div>

      {/* Project */}
      <div className="p-4 rounded-xl mb-3"
        style={{ background: 'rgba(201,150,79,0.06)', border: '1px solid rgba(201,150,79,0.15)' }}>
        <p className="font-semibold text-sm mb-1" style={{ color: '#3E1F0D' }}>{conn.project_title}</p>
        <p className="text-xs leading-relaxed" style={{ color: '#5A2D12' }}>{conn.project_description}</p>
      </div>

      {/* Requested slot */}
      <div className="flex items-center justify-between text-xs mb-3 flex-wrap gap-2">
        <span style={{ color: '#8A5A2B' }}>
          📅 Requested: <strong style={{ color: '#3E1F0D' }}>{conn.requested_slot}</strong>
        </span>
        {conn.suggested_time && (
          <span style={{ color: '#1d4ed8' }}>
            💡 Suggested: <strong>{conn.suggested_time}</strong>
          </span>
        )}
        <span className="text-xs" style={{ color: '#C9964F' }}>#{conn.request_id}</span>
      </div>

      {/* ── Action buttons (only for pending) ── */}
      {isPending && !suggestMode && (
        <div className="flex gap-2 flex-wrap">
          <button
            disabled={busy}
            onClick={() => act('Accepted', 'Faculty accepted the meeting request.')}
            className="flex-1 flex items-center justify-center gap-1.5 text-xs font-semibold py-2.5 px-4 rounded-xl transition-all hover:opacity-90 disabled:opacity-50"
            style={{ background: 'rgba(34,197,94,0.15)', color: '#166534', border: '1.5px solid rgba(34,197,94,0.4)' }}>
            ✅ Approve
          </button>
          <button
            disabled={busy}
            onClick={() => setSuggestMode(true)}
            className="flex-1 flex items-center justify-center gap-1.5 text-xs font-semibold py-2.5 px-4 rounded-xl transition-all hover:opacity-90 disabled:opacity-50"
            style={{ background: 'rgba(59,130,246,0.12)', color: '#1d4ed8', border: '1.5px solid rgba(59,130,246,0.35)' }}>
            📅 Suggest Time
          </button>
          <button
            disabled={busy}
            onClick={() => act('Rejected', 'Faculty declined the meeting request.')}
            className="flex-1 flex items-center justify-center gap-1.5 text-xs font-semibold py-2.5 px-4 rounded-xl transition-all hover:opacity-90 disabled:opacity-50"
            style={{ background: 'rgba(239,68,68,0.12)', color: '#991b1b', border: '1.5px solid rgba(239,68,68,0.35)' }}>
            ❌ Reject
          </button>
        </div>
      )}

      {/* ── Suggest time form ── */}
      {suggestMode && (
        <div className="p-4 rounded-xl animate-fadeIn"
          style={{ background: 'rgba(219,234,254,0.5)', border: '1px solid rgba(59,130,246,0.2)' }}>
          <p className="text-xs font-semibold mb-2" style={{ color: '#1e40af' }}>
            Suggest an alternative time slot:
          </p>
          <input
            className="search-input mb-3"
            style={{ padding: '9px 14px', fontSize: 13 }}
            placeholder="e.g. Friday 03:00 PM – 04:00 PM"
            value={suggestedTime}
            onChange={e => setSuggestedTime(e.target.value)}
          />
          <div className="flex gap-2">
            <button
              disabled={busy || !suggestedTime.trim()}
              onClick={() => act('Better time suggested', `Faculty suggested: ${suggestedTime}`, suggestedTime)}
              className="btn-primary flex-1 justify-center text-xs py-2 disabled:opacity-50">
              {busy ? '⏳' : '💡 Send Suggestion'}
            </button>
            <button
              onClick={() => { setSuggestMode(false); setSuggestedTime(''); }}
              className="btn-secondary text-xs py-2 px-4">
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Timeline */}
      {conn.status_timeline.length > 0 && (
        <div className="mt-4 pt-3 border-t" style={{ borderColor: 'rgba(201,150,79,0.15)' }}>
          <p className="text-xs font-semibold mb-2" style={{ color: '#8A5A2B' }}>Timeline</p>
          <div className="space-y-2">
            {conn.status_timeline.map((step, i) => (
              <div key={i} className="flex gap-2.5 text-xs">
                <div className="w-1.5 h-1.5 rounded-full mt-1.5 flex-shrink-0" style={{ background: '#C9964F' }} />
                <div>
                  <span className="font-semibold" style={{ color: '#5A2D12' }}>{step.step}</span>
                  <span style={{ color: '#A47242' }}> · {step.timestamp}</span>
                  <p className="mt-0.5" style={{ color: '#8A5A2B' }}>{step.note}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════════════════════
   Edit Profile Panel
══════════════════════════════════════════════════════════════════════════════ */
function EditProfilePanel({
  faculty,
  onSaved,
}: {
  faculty: Faculty;
  onSaved: (updated: Faculty) => void;
}) {
  const [designation, setDesignation]   = useState(faculty.designation);
  const [qualification, setQualification] = useState(faculty.qualification);
  const [primaryDomain, setPrimaryDomain] = useState(faculty.primary_domain);
  const [researchAreas, setResearchAreas] = useState(faculty.research_areas.join('\n'));
  const [scholarUrl, setScholarUrl]     = useState(faculty.google_scholar?.profile_url || '');
  const [linkedinUrl, setLinkedinUrl]   = useState(faculty.linkedin?.profile_url || '');
  const [bio, setBio]                   = useState(faculty.detailed_research_profile);
  const [saving, setSaving]             = useState(false);
  const [error, setError]               = useState('');

  const handleSave = async () => {
    setSaving(true);
    setError('');
    try {
      const areas = researchAreas
        .split('\n')
        .map(a => a.trim())
        .filter(Boolean);

      const res = await fetch('/api/faculty/update', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          faculty_id: faculty.chunk_id,
          updates: {
            designation,
            qualification,
            primary_domain: primaryDomain,
            research_areas: areas,
            scholar_url: scholarUrl,
            linkedin_url: linkedinUrl,
            detailed_research_profile: bio,
          },
        }),
      });
      const data = await res.json();
      if (data.success) {
        onSaved(data.faculty as Faculty);
      } else {
        setError(data.error || 'Save failed. Please try again.');
      }
    } catch {
      setError('Network error. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-4 animate-fadeIn">
      <div className="glass-card p-5">
        <h3 className="font-bold text-base mb-4" style={{ fontFamily: 'Outfit, sans-serif', color: '#3E1F0D' }}>
          ✏️ Edit Your Profile
        </h3>
        <p className="text-xs mb-5" style={{ color: '#A47242' }}>
          Changes are saved to the SAARTHI database and immediately visible to students.
        </p>

        <div className="space-y-4">
          {/* Designation */}
          <div>
            <label className="block text-xs font-semibold mb-1.5" style={{ color: '#5A2D12' }}>
              Designation
            </label>
            <input
              className="search-input"
              style={{ padding: '10px 14px', fontSize: 13 }}
              value={designation}
              onChange={e => setDesignation(e.target.value)}
            />
          </div>

          {/* Qualification */}
          <div>
            <label className="block text-xs font-semibold mb-1.5" style={{ color: '#5A2D12' }}>
              Qualification
            </label>
            <input
              className="search-input"
              style={{ padding: '10px 14px', fontSize: 13 }}
              value={qualification}
              onChange={e => setQualification(e.target.value)}
            />
          </div>

          {/* Primary domain */}
          <div>
            <label className="block text-xs font-semibold mb-1.5" style={{ color: '#5A2D12' }}>
              Primary Research Domain
            </label>
            <input
              className="search-input"
              style={{ padding: '10px 14px', fontSize: 13 }}
              placeholder="e.g. Deep Learning & Computer Vision"
              value={primaryDomain}
              onChange={e => setPrimaryDomain(e.target.value)}
            />
          </div>

          {/* Research areas */}
          <div>
            <label className="block text-xs font-semibold mb-1.5" style={{ color: '#5A2D12' }}>
              Research Areas <span style={{ color: '#A47242', fontWeight: 400 }}>(one per line)</span>
            </label>
            <textarea
              className="search-input"
              style={{ padding: '10px 14px', fontSize: 13, height: 120, resize: 'vertical' }}
              placeholder="Neural Networks&#10;Computer Vision&#10;Transfer Learning"
              value={researchAreas}
              onChange={e => setResearchAreas(e.target.value)}
            />
            <p className="text-xs mt-1" style={{ color: '#A47242' }}>
              {researchAreas.split('\n').filter(a => a.trim()).length} areas entered
            </p>
          </div>

          {/* LinkedIn Profile */}
          <div>
            <label className="block text-xs font-semibold mb-1.5" style={{ color: '#5A2D12' }}>
              LinkedIn Profile URL
            </label>
            <input
              className="search-input"
              style={{ padding: '10px 14px', fontSize: 13 }}
              placeholder="https://linkedin.com/in/username"
              value={linkedinUrl}
              onChange={e => setLinkedinUrl(e.target.value)}
            />
          </div>

          {/* Google Scholar Profile */}
          <div>
            <label className="block text-xs font-semibold mb-1.5" style={{ color: '#5A2D12' }}>
              Google Scholar Profile URL
            </label>
            <input
              className="search-input"
              style={{ padding: '10px 14px', fontSize: 13 }}
              placeholder="https://scholar.google.com/citations?user=..."
              value={scholarUrl}
              onChange={e => setScholarUrl(e.target.value)}
            />
          </div>

          {/* Bio / profile */}
          <div>
            <label className="block text-xs font-semibold mb-1.5" style={{ color: '#5A2D12' }}>
              Research Bio / Profile Description
            </label>
            <textarea
              className="search-input"
              style={{ padding: '10px 14px', fontSize: 13, height: 160, resize: 'vertical' }}
              value={bio}
              onChange={e => setBio(e.target.value)}
            />
          </div>

          {error && (
            <div className="p-3 rounded-xl text-xs"
              style={{ background: 'rgba(239,68,68,0.08)', color: '#991b1b', border: '1px solid rgba(239,68,68,0.2)' }}>
              ⚠️ {error}
            </div>
          )}

          <div className="flex gap-3">
            <button
              onClick={handleSave}
              disabled={saving}
              className="btn-primary flex-1 justify-center disabled:opacity-60">
              {saving ? '⏳ Saving…' : '💾 Save Profile'}
            </button>
            <button
              onClick={() => onSaved(faculty)}
              className="btn-secondary px-5">
              Cancel
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
