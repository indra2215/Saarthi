'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Image from 'next/image';

export default function FacultyLogin() {
  const router = useRouter();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [showPwd, setShowPwd] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !password) { setError('Please enter both username and password.'); return; }
    setLoading(true);
    setError('');

    try {
      const res = await fetch('/api/faculty-auth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
      });
      const data = await res.json();

      if (data.success) {
        // Store session in localStorage
        localStorage.setItem('saarthi_faculty_session', JSON.stringify({
          faculty_id: data.faculty_id,
          faculty_name: data.faculty_name,
          department_code: data.department_code,
          logged_in_at: Date.now(),
        }));
        router.push('/faculty/dashboard');
      } else {
        setError('Invalid credentials. Please check your username and password.');
      }
    } catch {
      setError('Connection error. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <main
      className="min-h-screen flex flex-col items-center justify-center relative overflow-hidden"
      style={{ background: 'linear-gradient(145deg, #FBF4E4 0%, #F3E6CC 50%, #EBDDBF 100%)' }}
    >
      {/* Background watermark */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <Image src="/saarthi-logo.png" alt="" width={480} height={480}
          className="object-contain opacity-[0.05]" />
      </div>

      {/* Decorative glows */}
      <div className="absolute top-[-80px] right-[-80px] w-64 h-64 rounded-full pointer-events-none"
        style={{ background: 'radial-gradient(circle, rgba(201,150,79,0.18) 0%, transparent 70%)' }} />

      <div className="relative z-10 w-full max-w-md px-6 animate-fadeIn">
        {/* Back button */}
        <button
          onClick={() => router.push('/')}
          className="mb-6 flex items-center gap-2 text-sm transition-colors"
          style={{ color: '#8A5A2B' }}
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
          Back to Home
        </button>

        <div className="glass-card p-8">
          {/* Brand */}
          <div className="flex items-center gap-3 mb-6">
            <Image src="/saarthi-logo.png" alt="SAARTHI" width={48} height={48} className="object-contain" />
            <div>
              <h1 className="text-2xl font-extrabold gradient-text" style={{ fontFamily: 'Outfit, sans-serif' }}>
                Faculty Portal
              </h1>
              <p className="text-xs" style={{ color: '#A47242' }}>Sign in with your SAARTHI credentials</p>
            </div>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            {/* Username */}
            <div>
              <label className="block text-xs font-semibold mb-1.5" style={{ color: '#5A2D12' }}>
                Username (Faculty ID)
              </label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm" style={{ color: '#C9964F' }}>👤</span>
                <input
                  type="text"
                  className="search-input"
                  style={{ paddingLeft: 36, paddingTop: 11, paddingBottom: 11 }}
                  placeholder="e.g. fac_1_4"
                  value={username}
                  onChange={e => setUsername(e.target.value)}
                  autoComplete="username"
                />
              </div>
            </div>

            {/* Password */}
            <div>
              <label className="block text-xs font-semibold mb-1.5" style={{ color: '#5A2D12' }}>
                Password
              </label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm" style={{ color: '#C9964F' }}>🔒</span>
                <input
                  type={showPwd ? 'text' : 'password'}
                  className="search-input"
                  style={{ paddingLeft: 36, paddingRight: 44, paddingTop: 11, paddingBottom: 11 }}
                  placeholder="Your password"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  autoComplete="current-password"
                />
                <button
                  type="button"
                  onClick={() => setShowPwd(!showPwd)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-sm transition-opacity"
                  style={{ color: '#A47242' }}
                >
                  {showPwd ? '🙈' : '👁'}
                </button>
              </div>
            </div>

            {/* Error */}
            {error && (
              <div className="text-xs p-3 rounded-xl" style={{ background: 'rgba(239,68,68,0.08)', color: '#991b1b', border: '1px solid rgba(239,68,68,0.2)' }}>
                ⚠️ {error}
              </div>
            )}

            {/* Submit */}
            <button type="submit" className="btn-primary w-full justify-center mt-2" disabled={loading}>
              {loading ? '⏳ Signing in…' : '🔓 Sign In'}
            </button>
          </form>

          {/* Demo credentials hint */}
          <div className="mt-5 p-3 rounded-xl" style={{ background: 'rgba(201,150,79,0.08)', border: '1px solid rgba(201,150,79,0.2)' }}>
            <p className="text-xs font-semibold mb-1.5" style={{ color: '#5A2D12' }}>Demo Credentials</p>
            <div className="space-y-1 text-xs" style={{ color: '#8A5A2B' }}>
              <div className="flex justify-between">
                <span>Dr. Aparna (CSE HOD)</span>
                <code className="font-mono" style={{ color: '#5A2D12' }}>fac_1_4 / kmeccse04</code>
              </div>
              <div className="flex justify-between">
                <span>Dr. R. Madhavi (AIML)</span>
                <code className="font-mono" style={{ color: '#5A2D12' }}>fac_2_4 / kmeccseaiml04</code>
              </div>
              <div className="flex justify-between">
                <span>Dr. V. PADMAVATHI (H&amp;S)</span>
                <code className="font-mono" style={{ color: '#5A2D12' }}>fac_5_3 / kmechs03</code>
              </div>
            </div>
          </div>
        </div>

        <p className="text-center text-xs mt-4" style={{ color: '#A47242' }}>
          KMEC — Keshav Memorial Engineering College, Hyderabad
        </p>
      </div>
    </main>
  );
}
