'use client';
import { useEffect } from 'react';
import { useRouter } from 'next/navigation';

export default function FacultyRoot() {
  const router = useRouter();
  useEffect(() => {
    const raw = localStorage.getItem('saarthi_faculty_session');
    if (raw) {
      router.replace('/faculty/dashboard');
    } else {
      router.replace('/faculty/login');
    }
  }, [router]);
  return null;
}
