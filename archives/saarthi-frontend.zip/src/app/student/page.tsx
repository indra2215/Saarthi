'use client';

import { useState, useCallback, useRef } from 'react';
import { useRouter } from 'next/navigation';
import Image from 'next/image';
import { Faculty } from '@/types';
import BookingModal from '@/components/BookingModal';
import FacultyDetailModal from '@/components/FacultyDetailModal';

const DEPT_LABELS: Record<string, string> = {
  'CSE': 'Computer Science',
  'CSE-AIML': 'AI & ML',
  'IT': 'Information Technology',
  'ECE-ALLIED': 'ECE & Allied',
  'H&S': 'Humanities & Sciences',
};
const DEPT_COLORS: Record<string, string> = {
  'CSE': '#3b82f6',
  'CSE-AIML': '#8b5cf6',
  'IT': '#10b981',
  'ECE-ALLIED': '#f59e0b',
  'H&S': '#ef4444',
};

const QUICK_HINTS = [
  'machine learning', 'blockchain', 'IoT', 'cloud computing',
  'VLSI', 'cybersecurity', 'deep learning', 'image processing',
  'data science', 'natural language processing',
];

export default function StudentPortal() {
  const router = useRouter();
  const [query, setQuery] = useState('');
  const [deptFilter, setDeptFilter] = useState('');
  const [phdFilter, setPhdFilter] = useState(false);
  const [scholarFilter, setScholarFilter] = useState(false);

  const [results, setResults] = useState<Faculty[]>([]);
  const [searched, setSearched] = useState(false);   // has user ever searched?
  const [loading, setLoading] = useState(false);

  const [selectedFaculty, setSelectedFaculty] = useState<Faculty | null>(null);
  const [bookingFaculty, setBookingFaculty] = useState<Faculty | null>(null);

  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const runSearch = useCallback(
    (q: string, dept: string, phd: boolean, scholar: boolean) => {
      if (!q.trim() && !dept && !phd && !scholar) {
        setResults([]);
        setSearched(false);
        setLoading(false);
        return;
      }
      setLoading(true);
      setSearched(true);
      const params = new URLSearchParams();
      if (q.trim()) params.set('q', q.trim());
      if (dept) params.set('dept', dept);
      if (phd) params.set('phd', 'true');
      if (scholar) params.set('scholar', 'true');

      fetch(`/api/faculty?${params}`)
        .then(r => r.json())
        .then((data: Faculty[]) => setResults(data))
        .finally(() => setLoading(false));
    },
    []
  );

  const handleQueryChange = (val: string) => {
    setQuery(val);
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => runSearch(val, deptFilter, phdFilter, scholarFilter), 280);
  };

  const handleFilterChange = (dept: string, phd: boolean, scholar: boolean) => {
    setDeptFilter(dept);
    setPhdFilter(phd);
    setScholarFilter(scholar);
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => runSearch(query, dept, phd, scholar), 0);
  };

  const clearAll = () => {
    setQuery('');
    setDeptFilter('');
    setPhdFilter(false);
    setScholarFilter(false);
    setResults([]);
    setSearched(false);
  };

  const hasActive = query.trim() !== '' || deptFilter !== '' || phdFilter || scholarFilter;

  return (
    <div className="min-h-screen flex flex-col"
      style={{ background: 'linear-gradient(180deg,#FBF4E4 0%,#F7ECD6 100%)' }}>

      {/* ── Nav ── */}
      <nav className="nav-bar px-5 py-3 flex items-center justify-between">
        <button onClick={() => router.push('/')} className="flex items-center gap-2.5">
          <Image src="/saarthi-logo.png" alt="SAARTHI" width={34} height={34} className="object-contain" />
          <span className="font-bold text-lg gradient-text" style={{ fontFamily: 'Outfit, sans-serif' }}>
            SAARTHI
          </span>
        </button>
        <div className="flex items-center gap-2">
          <span className="text-xs px-2 py-0.5 rounded-full"
            style={{ background: 'rgba(201,150,79,0.15)', color: '#8A5A2B' }}>
            🎓 Student Portal
          </span>
          {searched && (
            <span className="text-xs" style={{ color: '#A47242' }}>
              {loading ? '…' : `${results.length} found`}
            </span>
          )}
        </div>
      </nav>

      <div className="flex-1 max-w-6xl mx-auto w-full px-4 py-8">

        {/* ── Hero search area ── */}
        <div className={`transition-all duration-500 ${searched ? 'mb-5' : 'mb-0 flex flex-col items-center justify-center min-h-[55vh]'}`}>

          {/* Title (only when idle) */}
          {!searched && (
            <div className="text-center mb-8 animate-fadeIn">
              <h1 className="text-4xl font-extrabold mb-2 gradient-text"
                style={{ fontFamily: 'Outfit, sans-serif' }}>
                Find Your Research Mentor
              </h1>
              <p className="text-sm max-w-lg mx-auto" style={{ color: '#8A5A2B', lineHeight: 1.7 }}>
                Search across 131 KMEC faculty by research topic, domain, name or department.
                Discover expertise and book a meeting instantly.
              </p>
            </div>
          )}

          {/* Search box */}
          <div className={`w-full ${!searched ? 'max-w-2xl' : 'max-w-3xl'}`}>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-xl"
                style={{ color: '#C9964F', pointerEvents: 'none' }}>
                {loading ? '⏳' : '🔍'}
              </span>
              <input
                type="text"
                className="search-input"
                style={{
                  paddingLeft: 52,
                  paddingRight: hasActive ? 48 : 20,
                  paddingTop: 16,
                  paddingBottom: 16,
                  fontSize: 16,
                  borderRadius: 16,
                  boxShadow: '0 4px 20px rgba(62,31,13,0.08)',
                }}
                placeholder='Type a topic, faculty name, or domain… e.g. "machine learning", "blockchain"'
                value={query}
                onChange={e => handleQueryChange(e.target.value)}
                autoFocus
              />
              {hasActive && (
                <button
                  className="absolute right-4 top-1/2 -translate-y-1/2 w-7 h-7 rounded-full flex items-center justify-center transition-all hover:scale-110"
                  style={{ background: 'rgba(201,150,79,0.15)', color: '#8A5A2B' }}
                  onClick={clearAll}
                >✕</button>
              )}
            </div>

            {/* Filter chips */}
            <div className="flex flex-wrap gap-1.5 mt-3 items-center">
              <span className="text-xs font-medium" style={{ color: '#8A5A2B' }}>Filter:</span>
              {Object.keys(DEPT_LABELS).map(d => (
                <button key={d}
                  onClick={() => handleFilterChange(deptFilter === d ? '' : d, phdFilter, scholarFilter)}
                  className={`tag ${deptFilter === d ? 'tag-gold' : 'tag-brown'}`}
                  style={deptFilter === d ? { borderColor: DEPT_COLORS[d], color: DEPT_COLORS[d] } : {}}>
                  {DEPT_LABELS[d]}
                </button>
              ))}
              <div className="w-px h-3.5 mx-0.5" style={{ background: 'rgba(201,150,79,0.3)' }} />
              <button
                onClick={() => handleFilterChange(deptFilter, !phdFilter, scholarFilter)}
                className={`tag ${phdFilter ? 'tag-gold' : 'tag-brown'}`}>
                {phdFilter ? '✓ ' : ''}PhD Only
              </button>
              <button
                onClick={() => handleFilterChange(deptFilter, phdFilter, !scholarFilter)}
                className={`tag ${scholarFilter ? 'tag-gold' : 'tag-brown'}`}>
                {scholarFilter ? '✓ ' : ''}Has Google Scholar
              </button>
            </div>
          </div>

          {/* Quick hints (idle state) */}
          {!searched && (
            <div className="flex flex-wrap justify-center gap-2 mt-6 animate-fadeIn" style={{ animationDelay: '0.2s', opacity: 0 }}>
              {QUICK_HINTS.map(hint => (
                <button key={hint}
                  onClick={() => handleQueryChange(hint)}
                  className="tag tag-gold cursor-pointer hover:opacity-75 transition-opacity"
                  style={{ fontSize: 12, padding: '5px 13px' }}>
                  {hint}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* ── Results ── */}
        {searched && (
          <div className="animate-fadeIn">

            {/* Loading skeletons */}
            {loading && (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="faculty-card space-y-3">
                    <div className="flex items-center gap-3">
                      <div className="skeleton w-12 h-12 rounded-full" />
                      <div className="flex-1 space-y-2">
                        <div className="skeleton h-3.5 w-3/4" />
                        <div className="skeleton h-3 w-1/2" />
                      </div>
                    </div>
                    <div className="skeleton h-3 w-full" />
                    <div className="flex gap-1.5">
                      <div className="skeleton h-5 w-20 rounded-full" />
                      <div className="skeleton h-5 w-24 rounded-full" />
                    </div>
                    <div className="skeleton h-8 w-full rounded-xl" />
                  </div>
                ))}
              </div>
            )}

            {/* No results */}
            {!loading && results.length === 0 && (
              <div className="text-center py-20 animate-fadeIn">
                <div className="text-6xl mb-4">🔭</div>
                <h3 className="text-xl font-bold mb-2"
                  style={{ fontFamily: 'Outfit, sans-serif', color: '#5A2D12' }}>
                  No faculty found
                </h3>
                <p className="text-sm mb-5" style={{ color: '#A47242' }}>
                  Try different keywords or remove some filters.
                </p>
                <button className="btn-secondary" onClick={clearAll}>Clear all filters</button>
              </div>
            )}

            {/* Results grid */}
            {!loading && results.length > 0 && (
              <>
                <p className="text-sm mb-4" style={{ color: '#8A5A2B' }}>
                  <strong style={{ color: '#3E1F0D' }}>{results.length}</strong> faculty match your search
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {results.map((f, i) => (
                    <FacultyCard
                      key={f.chunk_id}
                      faculty={f}
                      deptColor={DEPT_COLORS[f.department_code] || '#C9964F'}
                      style={{ animationDelay: `${Math.min(i * 0.05, 0.5)}s`, opacity: 0 }}
                      onView={() => setSelectedFaculty(f)}
                      onBook={() => setBookingFaculty(f)}
                    />
                  ))}
                </div>
              </>
            )}
          </div>
        )}
      </div>

      {/* ── Modals ── */}
      {selectedFaculty && (
        <FacultyDetailModal
          faculty={selectedFaculty}
          onClose={() => setSelectedFaculty(null)}
          onBook={() => { setBookingFaculty(selectedFaculty); setSelectedFaculty(null); }}
        />
      )}
      {bookingFaculty && (
        <BookingModal faculty={bookingFaculty} onClose={() => setBookingFaculty(null)} />
      )}
    </div>
  );
}

// ── Faculty result card ────────────────────────────────────────────────────────
function FacultyCard({
  faculty: f,
  deptColor,
  style,
  onView,
  onBook,
}: {
  faculty: Faculty;
  deptColor: string;
  style?: React.CSSProperties;
  onView: () => void;
  onBook: () => void;
}) {
  return (
    <div
      className="faculty-card animate-fadeIn flex flex-col"
      style={{ ...style, borderLeft: `3px solid ${deptColor}` }}
      onClick={onView}
    >
      {/* Header row */}
      <div className="flex items-start gap-3 mb-3">
        <div
          className="w-12 h-12 rounded-full flex items-center justify-center text-2xl flex-shrink-0"
          style={{ background: `${deptColor}18`, border: `1.5px solid ${deptColor}33` }}>
          {f.photo_url
            ? <Image src={f.photo_url} alt={f.faculty_name} width={48} height={48}
                className="w-12 h-12 rounded-full object-cover" />
            : <span>{f.emoji}</span>}
        </div>
        <div className="min-w-0 flex-1">
          <h3 className="font-bold text-sm leading-snug"
            style={{ color: '#3E1F0D', fontFamily: 'Outfit, sans-serif' }}>
            {f.faculty_name}
          </h3>
          <p className="text-xs truncate mt-0.5" style={{ color: '#8A5A2B' }}>{f.designation}</p>
          <div className="flex flex-wrap gap-1 mt-1.5">
            <span className="tag tag-brown"
              style={{ fontSize: 10, padding: '1px 7px', borderColor: deptColor + '44', color: deptColor }}>
              {f.department_code}
            </span>
            {f.is_phd && <span className="tag tag-green" style={{ fontSize: 10, padding: '1px 6px' }}>PhD</span>}
            {f.is_hod && <span className="tag tag-gold" style={{ fontSize: 10, padding: '1px 6px' }}>HOD</span>}
            {f.similarity_score !== undefined && f.similarity_score > 0 && (
              <span className="tag"
                style={{
                  fontSize: 10,
                  padding: '1px 6px',
                  background: 'rgba(16,185,129,0.14)',
                  color: '#047857',
                  border: '1px solid rgba(16,185,129,0.35)',
                  fontWeight: 600,
                }}>
                ⚡ {f.similarity_score}% match
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Domain */}
      <p className="text-xs font-semibold mb-2 truncate" style={{ color: '#5A2D12' }}>
        {f.primary_domain}
      </p>

      {/* Research area tags */}
      <div className="flex flex-wrap gap-1 mb-3">
        {f.research_areas.slice(0, 3).map(area => (
          <span key={area} className="tag tag-gold" style={{ fontSize: 10, padding: '1px 7px' }}>{area}</span>
        ))}
        {f.research_areas.length > 3 && (
          <span className="tag tag-brown" style={{ fontSize: 10, padding: '1px 6px' }}>
            +{f.research_areas.length - 3}
          </span>
        )}
      </div>

      {/* External profile links */}
      <div className="flex gap-2 mb-3 flex-wrap">
        {f.google_scholar?.has_profile && f.google_scholar.profile_url ? (
          <a
            href={f.google_scholar.profile_url}
            target="_blank"
            rel="noopener noreferrer"
            onClick={e => e.stopPropagation()}
            className="flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-lg transition-all hover:opacity-80"
            style={{ background: 'rgba(59,130,246,0.09)', color: '#1d4ed8', border: '1px solid rgba(59,130,246,0.2)' }}>
            <span>📚</span> Google Scholar ↗
          </a>
        ) : (
          <span className="flex items-center gap-1 text-xs px-2 py-1 rounded-lg"
            style={{ background: 'rgba(0,0,0,0.04)', color: '#A47242', border: '1px solid rgba(0,0,0,0.08)' }}>
            No Scholar
          </span>
        )}
        {f.linkedin?.has_profile && f.linkedin.profile_url ? (
          <a
            href={f.linkedin.profile_url}
            target="_blank"
            rel="noopener noreferrer"
            onClick={e => e.stopPropagation()}
            className="flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-lg transition-all hover:opacity-80"
            style={{ background: 'rgba(10,102,194,0.09)', color: '#0a66c2', border: '1px solid rgba(10,102,194,0.2)' }}>
            <span>in</span> LinkedIn ↗
          </a>
        ) : (
          <span className="flex items-center gap-1 text-xs px-2 py-1 rounded-lg"
            style={{ background: 'rgba(0,0,0,0.04)', color: '#A47242', border: '1px solid rgba(0,0,0,0.08)' }}>
            No LinkedIn
          </span>
        )}
      </div>

      {/* Actions */}
      <div className="flex gap-2 mt-auto">
        <button
          className="btn-secondary flex-1 justify-center text-xs py-2"
          onClick={e => { e.stopPropagation(); onView(); }}>
          👤 View Profile
        </button>
        <button
          className="btn-primary flex-1 justify-center text-xs py-2"
          onClick={e => { e.stopPropagation(); onBook(); }}>
          📅 Book Meeting
        </button>
      </div>
    </div>
  );
}
