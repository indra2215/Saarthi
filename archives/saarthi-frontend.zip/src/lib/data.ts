import fs from 'fs';
import path from 'path';
import { Faculty, Availability, Connection } from '@/types';

const dataDir = path.join(process.cwd(), 'data');

let facultyCache: Faculty[] | null = null;
let availabilityCache: Record<string, Availability> | null = null;
let connectionsCache: Connection[] | null = null;

/** Call after writing faculty.enriched.json to force a fresh read */
export function invalidateFacultyCache() {
  facultyCache = null;
}

export function getAllFaculty(): Faculty[] {
  if (!facultyCache) {
    const raw = fs.readFileSync(path.join(dataDir, 'faculty.enriched.json'), 'utf-8');
    facultyCache = JSON.parse(raw);
  }
  return facultyCache!;
}

export function searchFaculty(query: string): Faculty[] {
  const all = getAllFaculty();
  if (!query.trim()) return all;
  const q = query.toLowerCase().trim();
  const terms = q.split(/\s+/);

  return all.filter((f) => {
    const searchText = [
      f.faculty_name,
      f.normalized_name,
      f.department,
      f.department_code,
      f.designation,
      f.primary_domain,
      ...f.research_areas,
      ...f.stated_topics,
      ...(f.inferred_topics || []).map((t) => t.topic),
      ...(f.aliases || []),
      f.rag_metadata.embedding_text,
      ...(f.rag_metadata.tokens || []),
    ]
      .join(' ')
      .toLowerCase();

    return terms.every((term) => searchText.includes(term));
  });
}

export function getFacultyById(id: string): Faculty | undefined {
  return getAllFaculty().find((f) => f.chunk_id === id);
}

export function getAvailability(): Record<string, Availability> {
  if (!availabilityCache) {
    const raw = fs.readFileSync(path.join(dataDir, 'availability.json'), 'utf-8');
    availabilityCache = JSON.parse(raw);
  }
  return availabilityCache!;
}

export function getConnections(): Connection[] {
  if (!connectionsCache) {
    const raw = fs.readFileSync(path.join(dataDir, 'connections.json'), 'utf-8');
    connectionsCache = JSON.parse(raw);
  }
  return connectionsCache!;
}

export function addConnection(conn: Connection): void {
  const connections = getConnections();
  connections.push(conn);
  connectionsCache = connections;
  fs.writeFileSync(
    path.join(dataDir, 'connections.json'),
    JSON.stringify(connections, null, 2)
  );
  // Also mark slot as booked
  const avail = getAvailability();
  if (avail[conn.faculty_id]) {
    const slot = avail[conn.faculty_id].slots.find((s) => s.time === conn.requested_slot);
    if (slot) {
      slot.is_booked = true;
      availabilityCache = avail;
      fs.writeFileSync(path.join(dataDir, 'availability.json'), JSON.stringify(avail, null, 2));
    }
  }
}

export function getDepartmentStats() {
  const all = getAllFaculty();
  const depts: Record<string, { count: number; label: string }> = {};
  all.forEach((f) => {
    if (!depts[f.department_code]) {
      depts[f.department_code] = { count: 0, label: f.department };
    }
    depts[f.department_code].count++;
  });
  return depts;
}

export function getTopResearchAreas(limit = 20) {
  const all = getAllFaculty();
  const counts: Record<string, number> = {};
  all.forEach((f) => {
    f.research_areas.forEach((area) => {
      counts[area] = (counts[area] || 0) + 1;
    });
  });
  return Object.entries(counts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, limit)
    .map(([area, count]) => ({ area, count }));
}

// Graph data for 3D force graph
export function getGraphData() {
  const all = getAllFaculty();
  const nodes: Record<string, { id: string; label: string; type: string; data?: Faculty }> = {};
  const links: { source: string; target: string; weight: number }[] = [];

  // Faculty nodes
  all.forEach((f) => {
    nodes[f.chunk_id] = { id: f.chunk_id, label: f.faculty_name, type: 'faculty', data: f };
  });

  // Topic nodes + links
  const topicMap: Record<string, string[]> = {};
  all.forEach((f) => {
    f.stated_topics.forEach((topic) => {
      const topicId = `topic_${topic.replace(/[^a-zA-Z0-9]/g, '_')}`;
      if (!nodes[topicId]) {
        nodes[topicId] = { id: topicId, label: topic, type: 'topic' };
      }
      if (!topicMap[topicId]) topicMap[topicId] = [];
      topicMap[topicId].push(f.chunk_id);
      links.push({ source: f.chunk_id, target: topicId, weight: 1.0 });
    });
  });

  // Dept nodes + links
  const deptMap: Record<string, string[]> = {};
  all.forEach((f) => {
    const deptId = `dept_${f.department_code}`;
    if (!nodes[deptId]) {
      nodes[deptId] = { id: deptId, label: f.department_code, type: 'department' };
    }
    if (!deptMap[deptId]) deptMap[deptId] = [];
    deptMap[deptId].push(f.chunk_id);
    links.push({ source: f.chunk_id, target: deptId, weight: 0.5 });
  });

  return { nodes: Object.values(nodes), links };
}
