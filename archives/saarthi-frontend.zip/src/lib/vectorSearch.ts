import fs from 'fs';
import path from 'path';
import { Faculty } from '@/types';
import { getAllFaculty, searchFaculty } from '@/lib/data';

interface VectorRecord {
  chunk_id: string;
  embedding: number[];
}

let vectorCache: Record<string, number[]> | null = null;
const vectorFilePath = path.join(process.cwd(), 'data', 'faculty.vectors.json');

/** Load pre-computed faculty embeddings into memory */
export function getFacultyVectors(): Record<string, number[]> {
  if (vectorCache) return vectorCache;

  if (!fs.existsSync(vectorFilePath)) {
    return {};
  }

  try {
    const raw = fs.readFileSync(vectorFilePath, 'utf-8');
    const records: VectorRecord[] = JSON.parse(raw);
    const map: Record<string, number[]> = {};
    for (const r of records) {
      if (r.chunk_id && r.embedding && r.embedding.length > 0) {
        map[r.chunk_id] = r.embedding;
      }
    }
    vectorCache = map;
    return map;
  } catch (err) {
    console.error('Failed to load faculty vectors:', err);
    return {};
  }
}

/** Cosine similarity between two dense vectors */
export function cosineSimilarity(a: number[], b: number[]): number {
  if (a.length !== b.length) return 0;
  let dot = 0;
  let normA = 0;
  let normB = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    normA += a[i] * a[i];
    normB += b[i] * b[i];
  }
  if (normA === 0 || normB === 0) return 0;
  return dot / (Math.sqrt(normA) * Math.sqrt(normB));
}

/** Embed a query string using Gemini embedding API */
export async function embedQuery(query: string): Promise<number[] | null> {
  const apiKey = process.env.GEMINI_API_KEY || 'AQ.Ab8RN6KM27--cpceBInW3dWkeehL4XLLHjxys0SIyTnQTVWUfg';
  if (!apiKey) return null;

  try {
    const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-embedding-001:embedContent?key=${apiKey}`;
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        content: { parts: [{ text: query.trim() }] },
      }),
    });

    if (!res.ok) {
      console.warn(`Gemini embed query returned HTTP ${res.status}`);
      return null;
    }

    const data = await res.json();
    return data.embedding?.values || null;
  } catch (err) {
    console.warn('Gemini embedding query error, falling back to lexical search:', err);
    return null;
  }
}

/**
 * True Semantic Vector Search:
 * 1. Embeds the user's natural language query using Gemini embedding-001
 * 2. Computes cosine similarity with all pre-embedded faculty chunks
 * 3. Ranks results by semantic similarity score
 * 4. Falls back to lexical token search if embedding API is unavailable
 */
export async function semanticSearchFaculty(query: string): Promise<Faculty[]> {
  const all = getAllFaculty();
  const trimmed = query.trim();
  if (!trimmed) return all;

  // Attempt dense vector semantic search
  const queryVector = await embedQuery(trimmed);
  const vectorMap = getFacultyVectors();

  if (queryVector && Object.keys(vectorMap).length > 0) {
    const scored: Array<{ faculty: Faculty; score: number }> = [];

    for (const f of all) {
      const vec = vectorMap[f.chunk_id];
      if (vec) {
        const score = cosineSimilarity(queryVector, vec);
        scored.push({ faculty: f, score });
      } else {
        scored.push({ faculty: f, score: 0 });
      }
    }

    // Sort descending by cosine similarity score
    scored.sort((a, b) => b.score - a.score);

    const maxScore = scored[0]?.score || 0;
    // Keep matches within 85% of top score or at least top 12 relevant candidates
    const threshold = Math.max(0.47, maxScore * 0.85);
    let candidates = scored.filter((item) => item.score >= threshold);

    if (candidates.length === 0) {
      candidates = scored.slice(0, 8);
    } else if (candidates.length > 20) {
      candidates = candidates.slice(0, 20);
    }

    return candidates.map((item) => {
      // Calculate normalized relative match percentage (e.g. 98%, 91%)
      const relativeMatch = maxScore > 0 ? Math.round((item.score / maxScore) * 100) : 0;
      return {
        ...item.faculty,
        similarity_score: relativeMatch,
      };
    });
  }

  // Graceful fallback to token & keyword matching
  return searchFaculty(trimmed);
}
